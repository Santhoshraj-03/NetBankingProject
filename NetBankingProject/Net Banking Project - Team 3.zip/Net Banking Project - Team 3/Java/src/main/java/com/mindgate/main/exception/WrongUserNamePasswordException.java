package com.mindgate.main.exception;

public class WrongUserNamePasswordException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WrongUserNamePasswordException() {
	}

	public WrongUserNamePasswordException(String message) {
		super(message);
	}

}
