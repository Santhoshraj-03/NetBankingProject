package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.domain.FixedDeposit;
import com.mindgate.main.exception.FixedDepositNotAddedException;
import com.mindgate.main.repository.AccountDetailsRepositoryInterface;
import com.mindgate.main.repository.FixedDepositRepositoryInterface;

@Service
public class FixedDepositService implements FixedDepositServiceInterface {
	@Autowired
	private FixedDepositRepositoryInterface fixedDepositRepository;
	@Autowired
	private AccountDetailsRepositoryInterface accountDetailsRepository;

	@Override
	public ResponseEntity<?> addFixedDeposit(FixedDeposit fixedDeposit) {

		AccountDetails accountDetails = accountDetailsRepository
				.getAccountDetailsByAccNumber(fixedDeposit.getAccNumber());

		if (accountDetails.getAccType().equalsIgnoreCase("savings")) {
			double balAmount = accountDetails.getBalance() - fixedDeposit.getFdAmount();
			if (balAmount >= TransactionDetailsService.miniBalance) {
				accountDetails.setBalance(balAmount);
				accountDetailsRepository.updateAccountDetails(accountDetails);

				boolean result = fixedDepositRepository.addFixedDeposit(fixedDeposit);
				if (result)
					return new ResponseEntity<>(fixedDeposit, HttpStatus.OK);
				else
					throw new FixedDepositNotAddedException();
			} else {
				return new ResponseEntity<>("Don't have required amount to create fixed deposit",
						HttpStatus.BAD_GATEWAY);
			}
		} else {
			return new ResponseEntity<>("Can't create Fixed depoit", HttpStatus.OK);
		}

	}

	@Override
	public ResponseEntity<?> getAllFixedDeposit(int userId) {
		List<FixedDeposit> fixedDepositList = fixedDepositRepository.getAllFixedDeposit(userId);
		return new ResponseEntity<>(fixedDepositList, HttpStatus.OK);
	}

}
