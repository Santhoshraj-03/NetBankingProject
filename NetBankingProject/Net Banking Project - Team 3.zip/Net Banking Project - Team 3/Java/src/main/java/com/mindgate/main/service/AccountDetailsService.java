package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.exception.AccountNotAddedException;
import com.mindgate.main.exception.AccountNotFoundException;
import com.mindgate.main.repository.AccountDetailsRepositoryInterface;

@Service
public class AccountDetailsService implements AccountDetailsServiceInterface {

	@Autowired
	private AccountDetailsRepositoryInterface accountDetailsRepository;

	@Override
	public ResponseEntity<?> addAccountDetails(AccountDetails accountDetails) {

		String odOpted = accountDetails.getOdOpted();
		if (odOpted == null || odOpted.equalsIgnoreCase("no")) {
			accountDetails.setOdBalance(0);
			accountDetails.setOdCharges(0);
			accountDetails.setOdOpted("no");
			accountDetails.setBalance(15000);
		} else {
			accountDetails.setBalance(15000);
			accountDetails.setOdBalance(50000);
		}
		System.out.println(accountDetails);
		boolean result = accountDetailsRepository.addAccountDetails(accountDetails);
		if (result) {
			List<AccountDetails> accountDetailsList = accountDetailsRepository
					.getAllAccountByUserId(accountDetails.getUserDetails().getUserId());
			return new ResponseEntity<>(accountDetailsList.get(accountDetailsList.size() - 1), HttpStatus.OK);
		} else
			throw new AccountNotAddedException();
	}

	@Override
	public ResponseEntity<?> getAllAccountDetails() {
		List<AccountDetails> accountDetailsList = accountDetailsRepository.getAllAccountDetails();
		return new ResponseEntity<List<AccountDetails>>(accountDetailsList, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getAccountDetailsByAccNumber(long accountNumber) {
		AccountDetails accountDetails = accountDetailsRepository.getAccountDetailsByAccNumber(accountNumber);
		if (accountDetails != null)
			return new ResponseEntity<AccountDetails>(accountDetails, HttpStatus.OK);
		else
			throw new AccountNotFoundException();
	}

	@Override
	public ResponseEntity<?> getAllAccountDetailsByUserId(int userId) {
		List<AccountDetails> accountDetailsList = accountDetailsRepository.getAllAccountByUserId(userId);
		return new ResponseEntity<>(accountDetailsList, HttpStatus.OK);
	}

}
