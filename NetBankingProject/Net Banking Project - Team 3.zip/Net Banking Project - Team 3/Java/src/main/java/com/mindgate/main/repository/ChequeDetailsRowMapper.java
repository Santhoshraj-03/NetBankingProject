package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.domain.ChequeDetails;

public class ChequeDetailsRowMapper implements RowMapper<ChequeDetails> {

	@Override
	public ChequeDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

//		long chequeNo = rs.getLong("cheque_no");
//		long issuerAccNo = rs.getLong("issure_acc_no");
//		long receiverAccNo = rs.getLong("receiver_acc_no");
//		double chequeAmount = rs.getDouble("cheque_amount");
//		Date chequeDate = rs.getDate("cheque_date");
//		Date clearancesDate = rs.getDate("clearance_date");
//		String status = rs.getString("status");
//
////		Receiver Account Details
//		long recAccountNumber = rs.getLong("acc_number");
//		int recUserId = rs.getInt("user_id");
//		double recBalance = rs.getDouble("balance");
//		String recOverdraftOpted = rs.getString("od_opted");
//		double recOverdraftBalance = rs.getDouble("od_balance");
//		double recOverdraftCharges = rs.getDouble("od_charges");
//		String recAccountType = rs.getString("acc_type");
//
////		Issuer Account Details
//		long issuerAccountNumber = rs.getLong("acc_number_1");
//		int issuerUserId = rs.getInt("user_id_1");
//		double issuerBalance = rs.getDouble("balance_1");
//		String issuerOverdraftOpted = rs.getString("od_opted_1");
//		double issuerOverdraftBalance = rs.getDouble("od_balance_1");
//		double issuerOverdraftCharges = rs.getDouble("od_charges_1");
//		String issuerAccountType = rs.getString("acc_type_1");
//
////		User Details
////		int userid = rs.getInt("user_id");
////		String firstName = rs.getString("first_name");
////		String lastName = rs.getString("last_name");
////		String emailId = rs.getString("email_id");
////		String address = rs.getString("address");
////		long mobile = rs.getLong("mobile");
////		Date date = rs.getDate("dob");
////		String gender = rs.getString("gender");
////		String userName = rs.getString("user_name");
////		String password = rs.getString("password");
////		int loginAccount = rs.getInt("login_count");
////		String accountStatus = rs.getString("acc_status");
//
////		UserDetails userDetails = new UserDetails(userid, firstName, lastName, emailId, address, mobile, date, gender,
////				userName, password, loginAccount, accountStatus);
//
//		UserDetails issuerUserDetails = new UserDetails();
//		issuerUserDetails.setUserId(issuerUserId);
//
//		UserDetails recUserDetails = new UserDetails();
//		recUserDetails.setUserId(recUserId);
//
//		AccountDetails issuerAccountDetails = new AccountDetails(issuerAccountNumber, issuerUserDetails, issuerBalance,
//				issuerOverdraftOpted, issuerOverdraftBalance, issuerOverdraftCharges, issuerAccountType);
//		AccountDetails receiverAccountDetails = new AccountDetails(recAccountNumber, recUserDetails, recBalance,
//				recOverdraftOpted, recOverdraftBalance, recOverdraftCharges, recAccountType);
//		ChequeDetails chequeDetails = new ChequeDetails(chequeNo, issuerAccountDetails, receiverAccountDetails,
//				chequeAmount, chequeDate, clearancesDate, status);
//		return chequeDetails;

		AccountDetails issuerAccountDetails = new AccountDetails();
		issuerAccountDetails.setAccNumber(rs.getLong("issuer_acc_no"));

		AccountDetails recAccountDetails = new AccountDetails();
		recAccountDetails.setAccNumber(rs.getLong("receiver_acc_no"));

		ChequeDetails chequeDetails = new ChequeDetails();
		chequeDetails.setChequeAmount(rs.getDouble("cheque_amount"));
		chequeDetails.setChequeDate(rs.getDate("cheque_date"));
		chequeDetails.setChequeNo(rs.getLong("cheque_no"));
		chequeDetails.setIssuerAccNo(issuerAccountDetails);
		chequeDetails.setReceiverAccNo(recAccountDetails);
		chequeDetails.setStatus(rs.getString("status"));

		return chequeDetails;
	}

}
