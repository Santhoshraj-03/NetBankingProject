package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.AccountDetails;

public interface AccountDetailsRepositoryInterface {

	public boolean addAccountDetails(AccountDetails accountDetails);

	public List<AccountDetails> getAllAccountDetails();

	public AccountDetails getAccountDetailsByAccNumber(long accountNumber);

//	public AccountDetails getAccountByUserId(int userId);

	public boolean updateAccountDetails(AccountDetails accountDetails);

	public List<AccountDetails> getAllAccountByUserId(int userId);
}
