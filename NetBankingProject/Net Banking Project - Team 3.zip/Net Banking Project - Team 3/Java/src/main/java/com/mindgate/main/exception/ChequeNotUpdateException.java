package com.mindgate.main.exception;

public class ChequeNotUpdateException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ChequeNotUpdateException() {
	}

	public ChequeNotUpdateException(String message) {
		super(message);
	}

}
