package com.mindgate.main.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.ChequeDetails;

@Repository
public class ChequeDetailsRepository implements ChequeDetailsRepositoryInterface {

	@Autowired
	public JdbcTemplate jdbcTemplate;

	private static final String ADD_CHEQUE_DEPOSIT = "INSERT INTO cheque_details(issuer_acc_no) VALUES(?)";
	private static final String GET_CHEQUE_DEPOSIT = "select * from cheque_details where issuer_acc_no = ?";
	private static final String DEPOSIT_CHEQUE = "UPDATE CHEQUE_DETAILS SET RECEIVER_ACC_NO = ?, CHEQUE_AMOUNT = ?, CHEQUE_DATE = ?,STATUS = ? WHERE CHEQUE_NO = ?";
	private static final String GET_CHEQUES_BY_STATUS = "SELECT * FROM CHEQUE_DETAILS WHERE STATUS = ?";
	private static final String GET_CHEQUES_SENT_FOR_CLAIM = "SELECT * FROM CHEQUE_DETAILS WHERE RECEIVER_ACC_NO = ? AND STATUS = 'sent for claim' AND trunc(CHEQUE_DATE) = ?";
	private static final String UPDATE_CHEQUE_STATUS = "UPDATE CHEQUE_DETAILS SET STATUS = ? WHERE CHEQUE_NO = ?";

	@Override
	public boolean addChequeDeposit(ChequeDetails chequeDetails) {
		int resultCount = jdbcTemplate.update(ADD_CHEQUE_DEPOSIT, chequeDetails.getIssuerAccNo().getAccNumber());
		if (resultCount > 0)
			return true;
		return false;
	}

	@Override
	public List<ChequeDetails> getAllChequeDetails(long issuserAccNo) {
		List<ChequeDetails> chequeDetailsList = jdbcTemplate.query(GET_CHEQUE_DEPOSIT, new ChequeDetailsRowMapper(),
				issuserAccNo);
		return chequeDetailsList;
	}

	public boolean depositCheque(ChequeDetails chequeDetails) {
		try {
			Object[] parameters = { chequeDetails.getReceiverAccNo().getAccNumber(), chequeDetails.getChequeAmount(),
					chequeDetails.getChequeDate(), chequeDetails.getStatus(), chequeDetails.getChequeNo() };
			int result = jdbcTemplate.update(DEPOSIT_CHEQUE, parameters);
			System.out.println(result);
			if (result > 0)
				return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	@Override
	public List<ChequeDetails> getChequesByStatus(String status) {
		try {
			List<ChequeDetails> notClearedCheqeues = jdbcTemplate.query(GET_CHEQUES_BY_STATUS,
					new ChequeDetailsRowMapper(), status);
			return notClearedCheqeues;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public List<ChequeDetails> getChequesSentForClaim(long receiverAccNo) {
		try {
			Object[] parameters = { receiverAccNo, LocalDate.now() };
			List<ChequeDetails> chequeDetailsList = jdbcTemplate.query(GET_CHEQUES_SENT_FOR_CLAIM,
					new ChequeDetailsRowMapper(), parameters);
			return chequeDetailsList;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean updateCheque(ChequeDetails chequeDetails) {
		try {
			Object[] parameters = { chequeDetails.getStatus(), chequeDetails.getChequeNo() };
			int result = jdbcTemplate.update(UPDATE_CHEQUE_STATUS, parameters);
			if (result > 0)
				return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

}
