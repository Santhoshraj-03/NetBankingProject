package com.mindgate.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.service.AccountDetailsServiceInterface;

@RestController
@RequestMapping("account")
@CrossOrigin("http://localhost:4200")
public class AccountDetailsController {

	@Autowired
	private AccountDetailsServiceInterface accountDetailsService;

	@PostMapping("add-account")
	public ResponseEntity<?> addAccountDetails(@RequestBody AccountDetails accountDetails) {
		return accountDetailsService.addAccountDetails(accountDetails);
	}

	@GetMapping("get-account-by-accnumber/{accNumber}")
	public ResponseEntity<?> getAccountDetailsByAccNumber(@PathVariable long accNumber) {
		return accountDetailsService.getAccountDetailsByAccNumber(accNumber);
	}

	@GetMapping("get-account/{userId}")
	public ResponseEntity<?> getAllAccountDetailsByUserId(@PathVariable int userId) {
		return accountDetailsService.getAllAccountDetailsByUserId(userId);
	}

}
