package com.mindgate.main.service;

import org.springframework.http.ResponseEntity;

import com.mindgate.main.domain.UserDetails;

public interface UserDetailsServiceInterface {

	public ResponseEntity<?> addUserDetails(UserDetails userDetails);

	public ResponseEntity<?> getAllUserDetails();

	public ResponseEntity<?> getUserDetailsByUserId(int userId);

	public ResponseEntity<?> verifyLogin(UserDetails userDetails);

	public ResponseEntity<?> getUsersForApproval();

	public ResponseEntity<?> approveUserByUserId(int userId);

	public ResponseEntity<?> reactivateUser(int userId);

	public ResponseEntity<?> getBlockedUsers();

	public ResponseEntity<?> updateUser(UserDetails userDetails);
}
