
package com.mindgate.main.exception;

public class ExcessAmountWithdrawException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExcessAmountWithdrawException() {
		// TODO Auto-generated constructor stub
	}

	public ExcessAmountWithdrawException(String message) {
		super(message);
	}

}
