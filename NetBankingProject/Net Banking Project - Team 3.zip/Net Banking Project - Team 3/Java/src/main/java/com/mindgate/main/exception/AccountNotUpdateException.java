
package com.mindgate.main.exception;

public class AccountNotUpdateException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNotUpdateException() {
		// TODO Auto-generated constructor stub
	}

	public AccountNotUpdateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
