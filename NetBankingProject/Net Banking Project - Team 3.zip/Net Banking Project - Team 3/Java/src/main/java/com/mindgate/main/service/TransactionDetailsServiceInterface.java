package com.mindgate.main.service;

import java.util.Date;

import org.springframework.http.ResponseEntity;

import com.mindgate.main.domain.TransactionDetails;

public interface TransactionDetailsServiceInterface {

	public ResponseEntity<?> addTransactionDetails(TransactionDetails transactionDetails);

	public ResponseEntity<?> getAllTransactionsByAccNo(long accNo);

	public ResponseEntity<?> getLast5TransactionsByAccNo(long accNo);

	public ResponseEntity<?> getTransactionsByDate(long accNo, Date fromDate, Date toDate);

}
