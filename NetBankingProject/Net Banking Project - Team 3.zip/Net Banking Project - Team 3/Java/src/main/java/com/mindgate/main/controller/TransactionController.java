package com.mindgate.main.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.TransactionDetails;
import com.mindgate.main.service.TransactionDetailsServiceInterface;

import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("transaction")
@CrossOrigin("http://localhost:4200")
public class TransactionController {

	@Autowired
	private TransactionDetailsServiceInterface transactionDetailsService;

	@PostMapping("add-transaction")
	public ResponseEntity<?> addTransactionDetails(@RequestBody TransactionDetails transactionDetails) {
		return transactionDetailsService.addTransactionDetails(transactionDetails);
	}

	@GetMapping("get-all-transactions/{accNo}")
	public ResponseEntity<?> getAllTransactionsByAccNo(@PathVariable long accNo) {
		return transactionDetailsService.getAllTransactionsByAccNo(accNo);
		
	}

	@GetMapping("last-5-transactions/{accNo}")
	public ResponseEntity<?> getLast5Transactions(@PathVariable long accNo) {
		return transactionDetailsService.getLast5TransactionsByAccNo(accNo);
	}

	@GetMapping("get-transactions-by-date")
	public ResponseEntity<?> getTransactionsByDate(@PathParam("accNo") long accNo, @PathParam("fromDate") Date fromDate,
			@PathParam("toDate") Date toDate) {
		return transactionDetailsService.getTransactionsByDate(accNo, fromDate, toDate);
	}
}
