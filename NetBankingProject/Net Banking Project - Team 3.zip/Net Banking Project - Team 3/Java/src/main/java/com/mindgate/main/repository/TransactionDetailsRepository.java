package com.mindgate.main.repository;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.TransactionDetails;
import com.mindgate.main.exception.TransactionFailedException;

@Repository
public class TransactionDetailsRepository implements TransactionDetailsRespositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String ADD_TRANSACTION = "INSERT INTO TRANSACTION_DETAILS (ACC_NO,TRANS_AMOUNT,TRANS_TYPE,RECEIVER_ACC_NO,STATUS,TRANS_DATE) VALUES (?,?,?,?,?,?)";
	private static final String GET_ALL_TRANSACTION_DETAILS = "SELECT * FROM TRANSACTION_DETAILS WHERE ACC_NO = ?";
	private static final String GET_LAST_5_TRANSACTIONS = "SELECT * FROM (SELECT * FROM transaction_details ORDER BY trans_id DESC )WHERE ROWNUM <= 5 and acc_no = ?";
	private static final String GET_TRANSACTIONS_BY_DATE = "select * from transaction_details where acc_no = ? and trans_date between ? and ?";
//	private static final String UPDATE_STATUS = "UPDATE TRANSACTION_DETAILS SET STATUS = ? WHERE TRANS_ID = ?";

	@Override
	public boolean addTransactionDetails(TransactionDetails transactionDetails) {
		System.out.println(transactionDetails);
		try {
			Object[] parameters = { transactionDetails.getAccNo(), transactionDetails.getTransAmount(),
					transactionDetails.getTransType(), transactionDetails.getReceiverAccNo(),
					transactionDetails.getStatus(), transactionDetails.getTransDate() };
			int result = jdbcTemplate.update(ADD_TRANSACTION, parameters);
			if (result > 0) {
				System.out.println("transaction added");
				return true;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new TransactionFailedException();
		}
		return false;
	}

	@Override
	public List<TransactionDetails> getAllTransactionsByAccNo(long accNo) {
		try {
			List<TransactionDetails> transactionDetailsList = jdbcTemplate.query(GET_ALL_TRANSACTION_DETAILS,
					new TransactionDetailsRowMapper(), accNo);
			return transactionDetailsList;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public List<TransactionDetails> getLast5TransactionsByAccNo(long accNo) {
		try {
			List<TransactionDetails> last5Transactions = jdbcTemplate.query(GET_LAST_5_TRANSACTIONS,
					new TransactionDetailsRowMapper(), accNo);
			System.out.println(last5Transactions);
			return last5Transactions;
		} catch (Exception e) {
			System.out.println("asdfasfdasdf");
			return null;
		}
	}

	@Override
	public List<TransactionDetails> getTransactionsByDate(long accNo, Date fromDate, Date toDate) {
		System.out.println(fromDate);
		try {
			Object[] parameters = { accNo, fromDate, toDate };
			List<TransactionDetails> transactionDetailsList = jdbcTemplate.query(GET_TRANSACTIONS_BY_DATE,
					new TransactionDetailsRowMapper(), parameters);
			return transactionDetailsList;
		} catch (Exception e) {
			return null;
		}
	}

}
