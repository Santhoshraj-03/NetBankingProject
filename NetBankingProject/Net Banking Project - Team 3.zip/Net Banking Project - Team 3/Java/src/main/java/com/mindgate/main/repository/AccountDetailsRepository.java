package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.exception.AccountNotUpdateException;

@Repository
public class AccountDetailsRepository implements AccountDetailsRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String ADD_ACCOUNT_DETAILS = "INSERT INTO account_details(user_id,acc_type,od_opted,od_charges,od_balance) VALUES(?,?,?,?,?)";
	private static final String GET_ACCOUNT_DETAILS = "SELECT * FROM account_details";
	private static final String GET_ACCOUNT_BY_ACC_NO = "SELECT * FROM account_details natural join user_details WHERE acc_number=?";
	private static final String GET_ALL_ACCOUNT_BY_USER_ID = "SELECT * FROM ACCOUNT_DETAILS natural join user_details WHERE USER_ID = ?";
	private static final String UPDATE_ACCOUNT_DETAILS = "UPDATE ACCOUNT_DETAILS SET BALANCE = ?,OD_BALANCE = ?,OD_CHARGES = ? WHERE ACC_NUMBER = ?";

	@Override
	public boolean addAccountDetails(AccountDetails accountDetails) {
		try {
			Object[] parameters = { accountDetails.getUserDetails().getUserId(), accountDetails.getAccType(),
					accountDetails.getOdOpted(), accountDetails.getOdCharges(), accountDetails.getOdBalance() };
			int resultCount = jdbcTemplate.update(ADD_ACCOUNT_DETAILS, parameters);

			if (resultCount > 0) {
				return true;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	@Override
	public List<AccountDetails> getAllAccountDetails() {
		List<AccountDetails> getAccountdetails = jdbcTemplate.query(GET_ACCOUNT_DETAILS, new AccountDetailsRowMapper());
		return getAccountdetails;
	}

	@Override
	public AccountDetails getAccountDetailsByAccNumber(long accountNumber) {
		try {
			AccountDetails accountDetails = jdbcTemplate.queryForObject(GET_ACCOUNT_BY_ACC_NO,
					new AccountDetailsRowMapper(), accountNumber);
			return accountDetails;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	@Override
	public boolean updateAccountDetails(AccountDetails accountDetails) {
		try {
			Object[] parameters = { accountDetails.getBalance(), accountDetails.getOdBalance(),
					accountDetails.getOdCharges(), accountDetails.getAccNumber() };
			int result = jdbcTemplate.update(UPDATE_ACCOUNT_DETAILS, parameters);
			if (result > 0)
				return true;
			return false;
		} catch (Exception e) {
			throw new AccountNotUpdateException();
		}
	}

	@Override
	public List<AccountDetails> getAllAccountByUserId(int userId) {
		try {
			List<AccountDetails> accountDetailsList = jdbcTemplate.query(GET_ALL_ACCOUNT_BY_USER_ID,
					new AccountDetailsRowMapper(), userId);
			if (accountDetailsList != null)
				return accountDetailsList;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

}
