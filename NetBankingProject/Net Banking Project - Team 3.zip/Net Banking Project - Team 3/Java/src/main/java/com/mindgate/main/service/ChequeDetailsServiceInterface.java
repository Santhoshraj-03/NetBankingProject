package com.mindgate.main.service;

import org.springframework.http.ResponseEntity;

import com.mindgate.main.domain.ChequeDetails;

public interface ChequeDetailsServiceInterface {

	public ResponseEntity<?> addChequeDeposit(ChequeDetails chequeDeposit);

	public ResponseEntity<?> getAllChequeDetails(long issuerAccNo);

	public ResponseEntity<?> depositCheque(ChequeDetails chequeDetails);

	public ResponseEntity<?> getClaimedCheques();

	public ResponseEntity<?> getChequesSentForClaim(long receiverAccNo);

	public ResponseEntity<?> updateCheque(ChequeDetails chequeDetails);

	public ResponseEntity<?> verifyCheque(ChequeDetails chequeDetails);

}
