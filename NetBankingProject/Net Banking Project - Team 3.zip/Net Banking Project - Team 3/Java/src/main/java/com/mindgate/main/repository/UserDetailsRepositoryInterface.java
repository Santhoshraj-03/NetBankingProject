package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.UserDetails;

public interface UserDetailsRepositoryInterface {

	public UserDetails addUserDetails(UserDetails userDetails);

	public List<UserDetails> getAllUserDetails();

	public UserDetails getUserDetailsByUserId(int userId);

	public List<UserDetails> getUsersForApproval();

	public UserDetails getUserByUserName(String userName);

	public boolean updateAccStatusByUserId(String status, int userId);

	public boolean updateLoginCount(int userId);

	public boolean resetLoginCount(int userId);

	public List<UserDetails> getBlockedUsers();

	public boolean updateUser(UserDetails userDetails);

}
