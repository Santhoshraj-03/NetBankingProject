package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.UserDetails;

@Repository
public class UserDetailsRepository implements UserDetailsRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String ADD_USER_DETAILS = "INSERT INTO USER_DETAILS (FIRST_NAME,LAST_NAME,EMAIL_ID,ADDRESS,MOBILE,DOB,GENDER,USER_NAME,PASSWORD) VALUES(?,?,?,?,?,?,?,?,?)";
	private static final String GET_ALL_USER_DETAILS = "SELECT * FROM USER_DETAILS";
	private static final String GET_USER_DETAILS_BY_ID = "SELECT * FROM USER_DETAILS WHERE USER_ID = ?";
	private static final String GET_USERS_FOR_APPROVAL = "SELECT * FROM USER_DETAILS WHERE ACC_STATUS = 'pending'";
	private static final String GET_BLOCKED_USERS = "SELECT * FROM USER_DETAILS WHERE ACC_STATUS = 'blocked'";
	private static final String GET_USER_BY_USERNAME = "SELECT * FROM USER_DETAILS WHERE USER_NAME = ?";
	private static final String UPDATE_ACC_STATUS = "UPDATE USER_DETAILS SET ACC_STATUS = ? WHERE USER_ID = ?";
	private static final String UPDATE_LOGIN_COUNT = "UPDATE USER_DETAILS SET LOGIN_COUNT = LOGIN_COUNT + 1 WHERE USER_ID = ?";
	private static final String RESET_LOGIN_COUNT = "UPDATE USER_DETAILS SET LOGIN_COUNT = 0 WHERE USER_ID = ?";
	private static final String UPDATE_USER = "update user_details set email_id = ?,address = ?,mobile = ?, password = ? where user_id = ?";

	@Override
	public UserDetails addUserDetails(UserDetails userDetails) {
		Object[] parameters = { userDetails.getFirstName(), userDetails.getLastName(), userDetails.getEmailId(),
				userDetails.getAddress(), userDetails.getMobile(), userDetails.getDob(), userDetails.getGender(),
				userDetails.getUserName(), userDetails.getPassword() };
		int result = jdbcTemplate.update(ADD_USER_DETAILS, parameters);
		if (result > 0)
			return userDetails;
		return null;
	}

	@Override
	public List<UserDetails> getAllUserDetails() {
		List<UserDetails> userDetailsList = jdbcTemplate.query(GET_ALL_USER_DETAILS, new UserDetailsRowMapper());
		return userDetailsList;
	}

	@Override
	public UserDetails getUserDetailsByUserId(int userId) {
		UserDetails userDetails = jdbcTemplate.queryForObject(GET_USER_DETAILS_BY_ID, new UserDetailsRowMapper(),
				userId);
		if (userDetails != null)
			return userDetails;
		else
			return null;
	}

	@Override
	public List<UserDetails> getUsersForApproval() {
		try {
			List<UserDetails> userDetailsList = jdbcTemplate.query(GET_USERS_FOR_APPROVAL, new UserDetailsRowMapper());
			return userDetailsList;
		} catch (Exception e) {
			System.out.println("asdfasdfds");
			return null;
		}
	}

	@Override
	public UserDetails getUserByUserName(String userName) {
		try {
			UserDetails userDetails = jdbcTemplate.queryForObject(GET_USER_BY_USERNAME, new UserDetailsRowMapper(),
					userName);
			return userDetails;

		} catch (Exception e) {
			return null;
		}

	}

	@Override
	public boolean updateAccStatusByUserId(String status, int userId) {
		Object[] parameters = { status, userId };
		int result = jdbcTemplate.update(UPDATE_ACC_STATUS, parameters);
		if (result > 0)
			return true;
		return false;
	}

	@Override
	public boolean updateLoginCount(int userId) {
		int result = jdbcTemplate.update(UPDATE_LOGIN_COUNT, userId);
		if (result > 0)
			return true;
		return false;
	}

	@Override
	public boolean resetLoginCount(int userId) {
		int result = jdbcTemplate.update(RESET_LOGIN_COUNT, userId);
		if (result > 0)
			return true;
		return false;
	}

	@Override
	public List<UserDetails> getBlockedUsers() {
		try {
			List<UserDetails> blockedUsers = jdbcTemplate.query(GET_BLOCKED_USERS, new UserDetailsRowMapper());
			return blockedUsers;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean updateUser(UserDetails userDetails) {
		Object[] parameters = { userDetails.getEmailId(), userDetails.getAddress(), userDetails.getMobile(),
				userDetails.getPassword(), userDetails.getUserId() };
		int result = jdbcTemplate.update(UPDATE_USER, parameters);
		if (result > 0)
			return true;
		return false;
	}

}
