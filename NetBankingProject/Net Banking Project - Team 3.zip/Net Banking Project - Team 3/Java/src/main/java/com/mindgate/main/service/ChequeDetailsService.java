package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.domain.ChequeDetails;
import com.mindgate.main.repository.AccountDetailsRepositoryInterface;
import com.mindgate.main.repository.ChequeDetailsRepositoryInterface;

@Service
public class ChequeDetailsService implements ChequeDetailsServiceInterface {

	@Autowired
	private ChequeDetailsRepositoryInterface chequeDetailsRepository;
	@Autowired
	private AccountDetailsRepositoryInterface accountDetailsRepository;

	@Override
	public ResponseEntity<?> addChequeDeposit(ChequeDetails chequeDetails) {
		for (int i = 1; i <= 5; i++) {
			chequeDetailsRepository.addChequeDeposit(chequeDetails);
		}
		return new ResponseEntity<>("Cheque details created", HttpStatus.OK);

	}

	@Override
	public ResponseEntity<?> getAllChequeDetails(long issuserAccNo) {
		List<ChequeDetails> chequeDetailsList = chequeDetailsRepository.getAllChequeDetails(issuserAccNo);
		return new ResponseEntity<>(chequeDetailsList, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> depositCheque(ChequeDetails chequeDetails) {
		chequeDetails.setStatus("sent for claim");
		boolean result = chequeDetailsRepository.depositCheque(chequeDetails);
		if (result)
			return new ResponseEntity<>(true, HttpStatus.OK);
		else {
			return new ResponseEntity<>(false, HttpStatus.BAD_GATEWAY);
		}
	}

	@Override
	public ResponseEntity<?> getClaimedCheques() {
		String status = "claimed";
		List<ChequeDetails> notClearedCheques = chequeDetailsRepository.getChequesByStatus(status);
		return new ResponseEntity<>(notClearedCheques, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getChequesSentForClaim(long receiverAccNo) {
		List<ChequeDetails> chequeDetailsList = chequeDetailsRepository.getChequesSentForClaim(receiverAccNo);
		if (chequeDetailsList != null)
			return new ResponseEntity<>(chequeDetailsList, HttpStatus.OK);
		return new ResponseEntity<>("Not get the cheque list", HttpStatus.BAD_GATEWAY);
	}

	@Override
	public ResponseEntity<?> updateCheque(ChequeDetails chequeDetails) {
		boolean result = chequeDetailsRepository.updateCheque(chequeDetails);
		if (result)
			return new ResponseEntity<>("Cheque claimed by payee", HttpStatus.OK);
		return new ResponseEntity<>("Cheque not claimed", HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> verifyCheque(ChequeDetails chequeDetails) {

		AccountDetails issuerAccountDetails = accountDetailsRepository
				.getAccountDetailsByAccNumber(chequeDetails.getIssuerAccNo().getAccNumber());

		String accType = issuerAccountDetails.getAccType();

		if (accType.equalsIgnoreCase("savings")) {
			double balAmount = issuerAccountDetails.getBalance() - chequeDetails.getChequeAmount();
			if (balAmount >= TransactionDetailsService.miniBalance)
				return new ResponseEntity<>(true, HttpStatus.OK);
			return new ResponseEntity<>(false, HttpStatus.BAD_GATEWAY);
		} else if (accType.equalsIgnoreCase("current")) {
			if (chequeDetails
					.getChequeAmount() <= (issuerAccountDetails.getBalance() + issuerAccountDetails.getOdBalance()))
				return new ResponseEntity<>(true, HttpStatus.OK);
			return new ResponseEntity<>(false, HttpStatus.BAD_GATEWAY);

		}
		return new ResponseEntity<>("Not able to get accounts", HttpStatus.OK);
	}

}
