package com.mindgate.main.exception;

import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;

public interface ExceptionCondition {

	public ResponseEntity<ProblemDetail> throwException(Exception e);
}
