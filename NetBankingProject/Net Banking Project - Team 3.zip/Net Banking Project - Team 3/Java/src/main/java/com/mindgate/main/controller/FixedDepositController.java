package com.mindgate.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.FixedDeposit;
import com.mindgate.main.service.FixedDepositServiceInterface;

@RestController
@RequestMapping("fd")
@CrossOrigin("http://localhost:4200")
public class FixedDepositController {

	@Autowired
	private FixedDepositServiceInterface fixedDepositService;

	@PostMapping("add-fd")
	public ResponseEntity<?> addFixedDeposit(@RequestBody FixedDeposit fixedDeposit) {
		return fixedDepositService.addFixedDeposit(fixedDeposit);
	}

	@GetMapping("get-all-fd/{userId}")
	public ResponseEntity<?> getAllFixedDeposit(@PathVariable int userId) {
		return fixedDepositService.getAllFixedDeposit(userId);
	}
}
