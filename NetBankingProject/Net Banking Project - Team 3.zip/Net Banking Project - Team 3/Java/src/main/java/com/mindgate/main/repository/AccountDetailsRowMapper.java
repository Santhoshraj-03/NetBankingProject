
package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.domain.UserDetails;

public class AccountDetailsRowMapper implements RowMapper<AccountDetails> {

	@Override
	public AccountDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		AccountDetails accountDetails = new AccountDetails();

		accountDetails.setAccNumber(rs.getLong("acc_number"));
		accountDetails.setBalance(rs.getDouble("balance"));
		accountDetails.setOdOpted(rs.getString("od_opted"));
		accountDetails.setOdBalance(rs.getDouble("od_balance"));
		accountDetails.setOdCharges(rs.getDouble("od_charges"));
		accountDetails.setAccType(rs.getString("acc_type"));

		UserDetails userDetails = new UserDetails();
		userDetails.setUserId(rs.getInt("user_id"));
		userDetails.setFirstName(rs.getString("first_name"));
		userDetails.setLastName(rs.getString("last_name"));
		userDetails.setEmailId(rs.getString("email_id"));
		userDetails.setAddress(rs.getString("address"));
		userDetails.setMobile(rs.getLong("mobile"));
		userDetails.setDob(rs.getDate("dob"));
		userDetails.setGender(rs.getString("gender"));
		userDetails.setUserName(rs.getString("user_name"));
		userDetails.setPassword(rs.getString("password"));
		userDetails.setLoginCount(rs.getInt("login_count"));
		userDetails.setAccStatus(rs.getString("acc_status"));
		accountDetails.setUserDetails(userDetails);

		return accountDetails;

	}

}
