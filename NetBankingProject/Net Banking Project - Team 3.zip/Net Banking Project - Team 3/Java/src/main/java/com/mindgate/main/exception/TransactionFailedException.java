package com.mindgate.main.exception;

public class TransactionFailedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public TransactionFailedException() {
		// TODO Auto-generated constructor stub
	}

	public TransactionFailedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
