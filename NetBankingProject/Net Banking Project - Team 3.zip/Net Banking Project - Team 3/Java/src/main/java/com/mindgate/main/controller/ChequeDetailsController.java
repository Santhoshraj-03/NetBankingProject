package com.mindgate.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.ChequeDetails;
import com.mindgate.main.service.ChequeDetailsServiceInterface;

@RestController
@RequestMapping("cheque")
@CrossOrigin("http://localhost:4200")
public class ChequeDetailsController {

	@Autowired
	private ChequeDetailsServiceInterface chequeDetailsService;

	@PostMapping("add-cheque")
	public ResponseEntity<?> addChequeDetails(@RequestBody ChequeDetails chequeDetails) {
		return chequeDetailsService.addChequeDeposit(chequeDetails);
	}

	@GetMapping("get-all-cheque/{issuerAccNo}")
	public ResponseEntity<?> getAllChequeDetails(@PathVariable long issuerAccNo) {
		return chequeDetailsService.getAllChequeDetails(issuerAccNo);
	}

	@PostMapping("deposit-cheque")
	public ResponseEntity<?> depositCheque(@RequestBody ChequeDetails chequeDetails) {
		return chequeDetailsService.depositCheque(chequeDetails);
	}

	@GetMapping("get-sent-claim/{receiverAccNo}")
	public ResponseEntity<?> getChequesSentForClaim(@PathVariable long receiverAccNo) {
		return chequeDetailsService.getChequesSentForClaim(receiverAccNo);
	}

	@PostMapping("update-cheque")
	public ResponseEntity<?> updateCheque(@RequestBody ChequeDetails chequeDetails) {
		return chequeDetailsService.updateCheque(chequeDetails);
	}
}
