package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.FixedDeposit;

@Repository
public class FixedDepositRepository implements FixedDepositRepositoryInterface {
	@Autowired
	public JdbcTemplate jdbcTemplate;
	private static final String ADD_FIXED_DEPOSIT = "INSERT INTO fixed_deposit(user_id,acc_number,fd_amount,roi,date_create,mature_date,tenure,mature_amount) VALUES(?,?,?,?,?,?,?,?)";
	private static final String GET_ALL_FIXED_DEPOSIT = "SELECT * FROM fixed_deposit where user_id = ?";

	@Override
	public boolean addFixedDeposit(FixedDeposit fixedDeposit) {
		Object[] parameters = { fixedDeposit.getUserDetails().getUserId(), fixedDeposit.getAccNumber(),
				fixedDeposit.getFdAmount(), fixedDeposit.getRoi(), fixedDeposit.getDateCreate(),
				fixedDeposit.getMatureDate(), fixedDeposit.getTenure(), fixedDeposit.getMatureAmount() };
		int resultCount = jdbcTemplate.update(ADD_FIXED_DEPOSIT, parameters);
		if (resultCount > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<FixedDeposit> getAllFixedDeposit(int userId) {
		List<FixedDeposit> getfixedDeposit = jdbcTemplate.query(GET_ALL_FIXED_DEPOSIT, new FixedDepositRowMapper(),
				userId);
		return getfixedDeposit;
	}

}
