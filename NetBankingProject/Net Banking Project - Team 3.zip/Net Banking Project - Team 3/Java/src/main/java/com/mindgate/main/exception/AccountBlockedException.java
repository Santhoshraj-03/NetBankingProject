package com.mindgate.main.exception;

public class AccountBlockedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AccountBlockedException() {
	}

	public AccountBlockedException(String message) {
		super(message);
	}

}
