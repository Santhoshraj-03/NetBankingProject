package com.mindgate.main.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.domain.TransactionDetails;
import com.mindgate.main.exception.AccountNotFoundException;
import com.mindgate.main.exception.ExcessAmountWithdrawException;
import com.mindgate.main.exception.MinimumBalanceException;
import com.mindgate.main.exception.TransactionFailedException;
import com.mindgate.main.repository.AccountDetailsRepositoryInterface;
import com.mindgate.main.repository.TransactionDetailsRespositoryInterface;

@Service
public class TransactionDetailsService implements TransactionDetailsServiceInterface {

	@Autowired
	private TransactionDetailsRespositoryInterface transactionDetailsRepository;
	@Autowired
	private AccountDetailsRepositoryInterface accountDetailsRepository;

	public static final double odLimit = 50000;
	public static final double miniBalance = 500;
	public static final double odROI = 0.10;

	@Override
	public ResponseEntity<?> addTransactionDetails(TransactionDetails transactionDetails) {

		TransactionDetails receiverTransaction = new TransactionDetails();
		receiverTransaction.setStatus("sucessful");
		receiverTransaction.setTransAmount(transactionDetails.getTransAmount());
		receiverTransaction.setTransDate(transactionDetails.getTransDate());
		receiverTransaction.setAccNo(transactionDetails.getReceiverAccNo());
		receiverTransaction.setReceiverAccNo(transactionDetails.getAccNo());
		receiverTransaction.setTransType("credited");

		double transactionAmount = transactionDetails.getTransAmount();

		AccountDetails recAccountDetails = accountDetailsRepository
				.getAccountDetailsByAccNumber(transactionDetails.getReceiverAccNo());
		System.out.println("Receiver Account Details : " + recAccountDetails);

		AccountDetails issuerAccountDetails = accountDetailsRepository
				.getAccountDetailsByAccNumber(transactionDetails.getAccNo());
		System.out.println("Issuer Account Details : " + issuerAccountDetails);

		if (recAccountDetails != null) {
			if (issuerAccountDetails.getAccType().equals("savings")) {
				double balanceAmount = issuerAccountDetails.getBalance() - transactionAmount;
				if (balanceAmount >= miniBalance) {
					issuerAccountDetails.setBalance(balanceAmount);
				} else {
					throw new MinimumBalanceException("Minimum balance exceeded");
				}
			} else {
				if (transactionAmount <= (issuerAccountDetails.getBalance() + issuerAccountDetails.getOdBalance())) {
					double balanceAmount = issuerAccountDetails.getBalance() - transactionAmount;
					issuerAccountDetails.setBalance(balanceAmount);
					if (balanceAmount < 0) {
						double balanceOdAmount = issuerAccountDetails.getOdBalance() + balanceAmount;
						System.out.println(issuerAccountDetails.getOdCharges());
						issuerAccountDetails
								.setOdCharges((Math.abs(balanceAmount) * odROI) + issuerAccountDetails.getOdCharges());
						issuerAccountDetails.setOdBalance(balanceOdAmount);
						issuerAccountDetails.setBalance(0);
					}
				} else {
					throw new ExcessAmountWithdrawException("Don't have required amount");
				}
			}
			if (recAccountDetails.getAccType().equals("savings") || recAccountDetails.getOdBalance() == odLimit) {
				recAccountDetails.setBalance(recAccountDetails.getBalance() + transactionAmount);
			} else {
				if (recAccountDetails.getOdBalance() < odLimit) {
					double balTransAmount = recAccountDetails.getOdCharges() - transactionAmount;
					recAccountDetails.setOdCharges(balTransAmount);
					if (balTransAmount < 0) {
						recAccountDetails.setOdCharges(0);
						double balanceOdAmount = recAccountDetails.getOdBalance() + Math.abs(balTransAmount) - odLimit;
						recAccountDetails.setOdBalance(recAccountDetails.getOdBalance() + Math.abs(balTransAmount));
						if (balanceOdAmount > 0) {
							recAccountDetails.setBalance(balanceOdAmount);
							recAccountDetails.setOdBalance(odLimit);
						}
					}
				}
			}
			accountDetailsRepository.updateAccountDetails(issuerAccountDetails);
			accountDetailsRepository.updateAccountDetails(recAccountDetails);

			boolean result = transactionDetailsRepository.addTransactionDetails(transactionDetails);
			boolean result2 = transactionDetailsRepository.addTransactionDetails(receiverTransaction);
			if (result && result2)
				return new ResponseEntity<>("transaction completed", HttpStatus.OK);
			else {
				throw new TransactionFailedException("Transaction Failed");
			}
		}
		throw new AccountNotFoundException("Receiver account not found");
	}

	@Override
	public ResponseEntity<?> getAllTransactionsByAccNo(long accNo) {
		List<TransactionDetails> transactionDetailsList = transactionDetailsRepository.getAllTransactionsByAccNo(accNo);
		return new ResponseEntity<>(transactionDetailsList, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getLast5TransactionsByAccNo(long accNo) {
		List<TransactionDetails> last5Transactions = transactionDetailsRepository.getLast5TransactionsByAccNo(accNo);
		System.out.println(last5Transactions);
		if (last5Transactions != null)
			return new ResponseEntity<>(last5Transactions, HttpStatus.OK);
		return new ResponseEntity<>("Transaction List not came", HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getTransactionsByDate(long accNo, Date fromDate, Date toDate) {
		List<TransactionDetails> transactionDetailsList = transactionDetailsRepository.getTransactionsByDate(accNo,
				fromDate, toDate);
		if (transactionDetailsList != null)
			return new ResponseEntity<>(transactionDetailsList, HttpStatus.OK);
		else
			return new ResponseEntity<>("Transaction details not received", HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
