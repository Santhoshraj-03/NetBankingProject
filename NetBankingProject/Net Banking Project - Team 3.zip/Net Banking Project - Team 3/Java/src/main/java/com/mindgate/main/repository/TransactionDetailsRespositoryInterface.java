package com.mindgate.main.repository;

import java.util.Date;
import java.util.List;

import com.mindgate.main.domain.TransactionDetails;

public interface TransactionDetailsRespositoryInterface {

	public boolean addTransactionDetails(TransactionDetails transactionDetails);

	public List<TransactionDetails> getAllTransactionsByAccNo(long accNo);

	public List<TransactionDetails> getLast5TransactionsByAccNo(long accNo);

	public List<TransactionDetails> getTransactionsByDate(long accNo, Date fromDate, Date toDate);
}
