package com.mindgate.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.ChequeDetails;
import com.mindgate.main.domain.TransactionDetails;
import com.mindgate.main.service.ChequeDetailsServiceInterface;
import com.mindgate.main.service.TransactionDetailsServiceInterface;
import com.mindgate.main.service.UserDetailsServiceInterface;

@RestController
@RequestMapping("admin")
@CrossOrigin("http://localhost:4200")
public class AdminController {

	@Autowired
	private UserDetailsServiceInterface userDetailsService;
	@Autowired
	private ChequeDetailsServiceInterface chequeDetailsService;
	@Autowired
	private TransactionDetailsServiceInterface transactionDetailsService;

	@GetMapping("get-pending-users")
	public ResponseEntity<?> getPendingUsers() {
		return userDetailsService.getUsersForApproval();
	}

	@PutMapping("verify-user/{userId}")
	public ResponseEntity<?> verifyUserByUserId(@PathVariable int userId) {
		return userDetailsService.approveUserByUserId(userId);
	}

	@PutMapping("unblock-user/{userId}")
	public ResponseEntity<?> unblockUserByUserId(@PathVariable int userId) {
		return userDetailsService.reactivateUser(userId);
	}

	@PutMapping("approve-cheque")
	public ResponseEntity<?> approveChequeDeposit(@RequestBody ChequeDetails chequeDetails) {
		String status = chequeDetails.getStatus();

		if (status.equalsIgnoreCase("cleared")) {

			TransactionDetails issuerTransaction = new TransactionDetails();
			issuerTransaction.setAccNo(chequeDetails.getIssuerAccNo().getAccNumber());
			issuerTransaction.setReceiverAccNo(chequeDetails.getReceiverAccNo().getAccNumber());
			issuerTransaction.setTransAmount(chequeDetails.getChequeAmount());
			issuerTransaction.setStatus("sucessful");
			issuerTransaction.setTransType("Cheque Deposit");
			issuerTransaction.setTransDate(chequeDetails.getChequeDate());

			ResponseEntity<?> result = transactionDetailsService.addTransactionDetails(issuerTransaction);
			String output = result.getBody().toString();
			System.out.println(output);

		}
		return chequeDetailsService.updateCheque(chequeDetails);
	}

	@GetMapping("get-blocked-users")
	public ResponseEntity<?> getBlockedUsers() {
		return userDetailsService.getBlockedUsers();
	}

	@GetMapping("get-claimed-cheques")
	public ResponseEntity<?> getClaimedCheques() {
		return chequeDetailsService.getClaimedCheques();
	}

	@GetMapping("verify-cheque")
	public ResponseEntity<?> verifyCheque(@RequestBody ChequeDetails chequeDetails) {
		return chequeDetailsService.verifyCheque(chequeDetails);
	}
}
