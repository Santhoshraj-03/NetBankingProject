package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.ChequeDetails;

public interface ChequeDetailsRepositoryInterface {

	public boolean addChequeDeposit(ChequeDetails chequeDetails);

	public List<ChequeDetails> getAllChequeDetails(long accNo);

	public boolean depositCheque(ChequeDetails chequeDetails);

	public List<ChequeDetails> getChequesByStatus(String status);

	public List<ChequeDetails> getChequesSentForClaim(long receiverAccNo);

	public boolean updateCheque(ChequeDetails chequeDetails);

}
