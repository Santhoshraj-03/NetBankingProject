package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.AccountDetails;
import com.mindgate.main.domain.UserDetails;
import com.mindgate.main.exception.AccountBlockedException;
import com.mindgate.main.exception.AccountNotVerifiedException;
import com.mindgate.main.exception.UserAlreadyExistsException;
import com.mindgate.main.exception.UserNotAddedException;
import com.mindgate.main.exception.UserNotFoundException;
import com.mindgate.main.exception.WrongUserNamePasswordException;
import com.mindgate.main.repository.AccountDetailsRepositoryInterface;
import com.mindgate.main.repository.UserDetailsRepositoryInterface;

@Service
public class UserDetailsService implements UserDetailsServiceInterface {

	@Autowired
	private UserDetailsRepositoryInterface userDetailsRepository;
	@Autowired
	private AccountDetailsRepositoryInterface accountDetailsRepository;

	@Override
	public ResponseEntity<?> addUserDetails(UserDetails userDetails) {

		UserDetails userDetails2 = userDetailsRepository.getUserByUserName(userDetails.getUserName());

		if (userDetails2 == null) {
			userDetailsRepository.addUserDetails(userDetails);
			UserDetails ud = userDetailsRepository.getUserByUserName(userDetails.getUserName());
			if (ud != null)
				return new ResponseEntity<>(ud, HttpStatus.OK);
			else
				throw new UserNotAddedException();
		} else
			throw new UserAlreadyExistsException();
	}

	@Override
	public ResponseEntity<?> getAllUserDetails() {
		List<UserDetails> userDetailsList = userDetailsRepository.getAllUserDetails();
		return new ResponseEntity<>(userDetailsList, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getUserDetailsByUserId(int userId) {
		UserDetails userDetails = userDetailsRepository.getUserDetailsByUserId(userId);
		if (userDetails != null)
			return new ResponseEntity<>(userDetails, HttpStatus.OK);
		else
			throw new UserNotFoundException();

	}

	@Override
	public ResponseEntity<?> verifyLogin(UserDetails userDetails) {

		UserDetails userDetails2 = userDetailsRepository.getUserByUserName(userDetails.getUserName());
		String userName = userDetails2.getUserName();
		String password = userDetails2.getPassword();
		String acc_status = userDetails2.getAccStatus();
		int loginCount = userDetails2.getLoginCount();
		int userId = userDetails2.getUserId();

		if (acc_status.equals("verified")) {
			if (loginCount < 3) {
				if (userName.equals(userDetails.getUserName()) && password.equals(userDetails.getPassword())) {
					userDetailsRepository.resetLoginCount(userId);
					List<AccountDetails> accountDetailsList = accountDetailsRepository.getAllAccountByUserId(userId);
					return new ResponseEntity<>(accountDetailsList, HttpStatus.OK);
				} else {
					userDetailsRepository.updateLoginCount(userId);
					throw new WrongUserNamePasswordException();
				}
			} else {
				userDetailsRepository.updateAccStatusByUserId("blocked", userId);
				userDetailsRepository.resetLoginCount(userId);
				throw new AccountBlockedException();
			}
		} else if (acc_status.equals("pending")) {
			throw new AccountNotVerifiedException();
		} else {
			throw new AccountBlockedException();
		}
	}

	@Override
	public ResponseEntity<?> getUsersForApproval() {
		List<UserDetails> userDetailsForApproval = userDetailsRepository.getUsersForApproval();
		return new ResponseEntity<>(userDetailsForApproval, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> approveUserByUserId(int userId) {
		String status = "verified";
		boolean result = userDetailsRepository.updateAccStatusByUserId(status, userId);
		if (result)
			return new ResponseEntity<>("User verified", HttpStatus.OK);
		return new ResponseEntity<>("User not verified", HttpStatus.NOT_MODIFIED);
	}

	@Override
	public ResponseEntity<?> reactivateUser(int userId) {
		boolean result = userDetailsRepository.updateAccStatusByUserId("verified", userId);
		if (result)
			return new ResponseEntity<>("User reactivated", HttpStatus.OK);
		return new ResponseEntity<>("User not reactivated", HttpStatus.BAD_GATEWAY);
	}

	@Override
	public ResponseEntity<?> getBlockedUsers() {
		List<UserDetails> blockedUsers = userDetailsRepository.getBlockedUsers();
		if (blockedUsers != null)
			return new ResponseEntity<>(blockedUsers, HttpStatus.OK);
		return new ResponseEntity<>("Not getting blocked users", HttpStatus.BAD_GATEWAY);
	}

	@Override
	public ResponseEntity<?> updateUser(UserDetails userDetails) {
		boolean result = userDetailsRepository.updateUser(userDetails);
		if (result)
			return new ResponseEntity<>(true, HttpStatus.OK);
		return new ResponseEntity<>(false, HttpStatus.OK);
	}

}
