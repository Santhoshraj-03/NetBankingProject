package com.mindgate.main.exception;

public class ChequeqNotAddedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ChequeqNotAddedException() {
	}

	public ChequeqNotAddedException(String message) {
		super(message);
	}

}
