package com.mindgate.main.exception;

public class AccountNotAddedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AccountNotAddedException() {
	}

	public AccountNotAddedException(String message) {
		super(message);
	}

}
