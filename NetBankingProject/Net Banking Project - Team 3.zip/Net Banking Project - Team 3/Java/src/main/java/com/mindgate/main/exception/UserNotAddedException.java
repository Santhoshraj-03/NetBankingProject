package com.mindgate.main.exception;

public class UserNotAddedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserNotAddedException() {

	}

	public UserNotAddedException(String message) {
		super(message);
	}

}
