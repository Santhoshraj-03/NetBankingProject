import { NgModule } from '@angular/core';
import { UserloginComponent } from './userlogin/userlogin.component';
import { MoneytransferComponent } from './moneytransfer/moneytransfer.component';
import { RegisterComponent } from './register/register.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { HomepageComponent } from './homepage/homepage.component';
import {  RouterModule,Routes } from '@angular/router';
import { UserhomepageComponent } from './userhomepage/userhomepage.component';
import { ProfilesummaryComponent } from './profilesummary/profilesummary.component';
import { FixedDepositComponent } from './fixeddeposit/fixeddeposit.component';
import { ChequeDepositComponent } from './chequedeposit/chequedeposit.component';
import { TransactionDetailsComponent } from './transactiondetails/transactiondetails.component';
import { MiniStatementComponent } from './ministatement/ministatement.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { Updatedetailscomponent } from './updatedetails/updatedetails.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { ChequeValidationComponent } from './adminpage/cheque-validation/cheque-validation.component';
import { ReactivateAccountComponent } from './adminpage/reactivate-account/reactivate-account.component';
import { UserRequestComponent } from './adminpage/user-request/user-request.component';
import { CreatedepositComponent } from './createdeposit/createdeposit.component';
import { ShowdepositsComponent } from './showdeposits/showdeposits.component';
import { ShowchequedepositComponent } from './showchequedeposit/showchequedeposit.component';
import { ChequeComponent } from './cheque/cheque.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'userhome', component: UserhomepageComponent },
  { path: 'home', component: HomepageComponent },
  { path: 'userlogin', component: UserloginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'adminlogin', component: AdminloginComponent },
  { path: 'profile', component: ProfilesummaryComponent },
  { path: 'fixeddeposit', component: FixedDepositComponent },
  { path: 'moneytransfer', component: MoneytransferComponent },
  { path: 'chequedeposit', component: ChequeDepositComponent },
  { path: 'transactiondetails', component: TransactionDetailsComponent },
  { path: 'ministatement', component: MiniStatementComponent },
  { path: 'createaccount', component: CreateaccountComponent },
  { path: 'updatedetails', component: Updatedetailscomponent },
  { path: 'forgotpassword', component: ForgotpasswordComponent },
  { path: 'adminpage', component: AdminpageComponent },
  { path: 'cvalid', component: ChequeValidationComponent },
  {path:'reactivate',component:ReactivateAccountComponent},
  {path:'urequest',component:UserRequestComponent},
  {path:'cdeposit',component:CreatedepositComponent},
  {path:'sdeposit',component:ShowdepositsComponent},
  {path:'scheque',component:ShowchequedepositComponent},
  {path:'cheque',component:ChequeComponent},



  

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
