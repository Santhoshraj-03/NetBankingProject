import { Component, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { AccountService } from '../account.service';
import { AccountDetails } from '../models/account-details';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ChequeDetails } from '../models/cheque-details';

@Component({
  selector: 'app-cheque-deposit',
  templateUrl: './chequedeposit.component.html',
  styleUrls: ['./chequedeposit.component.css']
})
export class ChequeDepositComponent {
  isNavbarOpen: boolean = false;
  chequeDepositForm!: FormGroup;
  accountDetails!: AccountDetails ;
  chequeNo!: any;

  accountNumbers: string[] = [];
  accountNo!: any;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private route: ActivatedRoute, // Inject ActivatedRoute
    private ac: AccountService
  ) { }

  toggleNavbar() {
    this.isNavbarOpen = !this.isNavbarOpen;
  }

  @HostListener('document:click', ['$event'])
  onClick(event: Event) {
    if (this.isNavbarOpen) {
      const target = event.target as HTMLElement;
      if (!target.closest('.navbar') && !target.closest('.hamburger-menu')) {
        this.isNavbarOpen = false;
      }
    }
  }

  ngOnInit(): void {
    this.createChequeDepositForm();


   
    this.route.params.subscribe(params => {
      this.accountNo = +params['accountNo'];
      this.chequeNo = +params['chequeNo'];
      // Now you have both accountNo and chequeNo parameters available
      console.log('Account Number:', this.accountNo);
      console.log('Cheque Number:', this.chequeNo);

   
    });
  }

  createChequeDepositForm() {
    this.chequeDepositForm = this.fb.group({
      
      receiverAccountNumber: ['', Validators.required],
      chequeAmount: ['', Validators.required],
      chequeDate: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.chequeDepositForm.valid) {
     
      const chequeDetails: any = {
        chequeNo: this.chequeNo,
        issuerAccNo: {
            accNumber: this.accountNo
        },
        receiverAccNo: {
            accNumber: this.chequeDepositForm.value.receiverAccountNumber,
        },
        chequeAmount:this.chequeDepositForm.value.chequeAmount,
        chequeDate: this.chequeDepositForm.value.chequeDate,
        status: "",
        clearanceDate: null
    };
    

      this.http.post<ChequeDetails>('http://172.27.17.150:8080/cheque/deposit-cheque', chequeDetails)
        .subscribe(
          response => {
            console.log('Cheque details posted successfully:', response);
            alert("deposited successfully");
          },
          error => {
            console.error('Error posting cheque details:', error);
            alert("deposit failed");
          }
        );
    } else {
      alert("deposit failed");
      console.error('Form submission failed. Please check the form for errors.');
    }
  }
}
