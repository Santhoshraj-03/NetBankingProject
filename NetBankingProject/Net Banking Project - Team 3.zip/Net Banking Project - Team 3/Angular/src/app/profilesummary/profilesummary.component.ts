import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-profilesummary',
  templateUrl: './profilesummary.component.html',
  styleUrls: ['./profilesummary.component.css']
})
export class ProfilesummaryComponent implements OnInit {
  user: any;
  accountDetails: any=[];

  constructor(private userService: UserService,private router:Router) {}

  ngOnInit(): void {
    this.accountDetails = JSON.parse(localStorage.getItem("currentAccountDetails") || '{}');
    console.log(this.accountDetails);
  }

  getUserDetails(): void {
    // this.userService.getUserDetails().subscribe(
    //   (data: any) => {
    //     this.user = data;
    //   },
    //   (error: any) => {
    //     console.error('Error fetching user details:', error);
    //   }
    // );
  }

  updateDetails(): void {
    this.router.navigate(['/updatedetails']);
  }
}