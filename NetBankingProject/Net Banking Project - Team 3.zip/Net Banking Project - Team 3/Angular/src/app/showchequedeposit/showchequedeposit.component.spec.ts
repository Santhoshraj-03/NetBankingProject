import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowchequedepositComponent } from './showchequedeposit.component';

describe('ShowchequedepositComponent', () => {
  let component: ShowchequedepositComponent;
  let fixture: ComponentFixture<ShowchequedepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowchequedepositComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowchequedepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
