import { HttpClient } from '@angular/common/http';
import { Component, HostListener, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AccountService } from '../account.service';

import { AccountDetails } from '../models/account-details';

@Component({
  selector: 'app-showchequedeposit',
  templateUrl: './showchequedeposit.component.html',
  styleUrls: ['./showchequedeposit.component.css']
})
export class ShowchequedepositComponent implements OnInit {
  



chequeDeposits: ChequeDetails[] = [];
accountDetails:AccountDetails[]=[];
selectedAccountNumber!:any;
claimDeposits:ChequeDetails[]=[];



constructor(private http: HttpClient, private route: ActivatedRoute,private accountService: AccountService) {}




ngOnInit(): void {
  this.selectedAccountNumber = this.accountService.selectedAccountNumber;
  console.log(this.selectedAccountNumber);
  
  this.fetchChequeDetails(this.selectedAccountNumber);
  this.fetchClaimDetails(this.selectedAccountNumber);
  
 
}



fetchChequeDetails(selectedAccountNumber: number): void {
  this.http.get<ChequeDetails[]>(`http://172.27.17.150:8080/cheque/get-all-cheque/${this.selectedAccountNumber}`)
    .subscribe((response) => {
      this.chequeDeposits = response;
      console.log(response);
      if (response.length > 0) {
        this.accountService.chequeNo = response[0].chequeNo;
      }
      
    });
}
fetchClaimDetails(selectedAccountNumber: number): void {
  this.http.get<ChequeDetails[]>(`http://172.27.17.150:8080/cheque/get-sent-claim/${this.selectedAccountNumber}`)
    .subscribe((response) => {
      this.claimDeposits = response;
      console.log(response);
      if (response.length > 0) {
        this.accountService.chequeNo = response[0].chequeNo;
      }
      
    });
}



claimCheque(cheque: ChequeDetails): void {
  cheque.status = 'claimed';

  this.http.post('http://172.27.17.150:8080/cheque/update-cheque', cheque)
    .subscribe(
      response => {
        alert("cheque created successfully")
        console.log('Cheque details updated successfully:', response);
        // Handle success response as needed
      },
      error => {
        console.error('Error updating cheque details:', error);
        // Handle error response as needed
      }
    );
}


}

export interface ChequeDetails {
chequeNo: number;
issuerAccNo: AccountDetails;
receiverAccNo: number;
chequeAmount: number;
chequeDate: Date;
status: string | null;
}