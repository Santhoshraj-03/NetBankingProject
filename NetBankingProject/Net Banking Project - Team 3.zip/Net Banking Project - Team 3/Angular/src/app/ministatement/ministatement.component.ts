import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { TransactionDetails } from '../models/transaction-details';
import { TransactionService } from '../services/transaction.service';
import { HttpClient } from '@angular/common/http';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './ministatement.component.html',
  styleUrls: ['./ministatement.component.css']
})
export class MiniStatementComponent implements OnInit {
  statementForm!: FormGroup;
  transactions: any[] = [];
  // Assuming you have a variable to hold the account number
accountNo=this.accountService.selectedAccountNumber
  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient,
    private accountService: AccountService
  ) { }
 
  

  ngOnInit(): void {
    this.fetchTransactions(this.accountNo);

    // Initialize the statement form
    this.statementForm = this.formBuilder.group({
      date: [''],
      type: [''],
      amount: [''],
      balance: ['']
    });
  }

  fetchTransactions(accountNumber: number): void {
    this.http.get<any[]>(`http://172.27.17.150:8080/transaction/last-5-transactions/${accountNumber}`)
    .subscribe(
      (response) => {
        this.transactions = response;
        console.log(response);
      },
      (error) => {
        console.error('Error fetching transactions:', error);
        // Handle error (e.g., display an error message)
      }
    );
  }
}
