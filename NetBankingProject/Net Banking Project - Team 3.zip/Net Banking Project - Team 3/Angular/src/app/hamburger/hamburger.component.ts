import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-hamburger',
  templateUrl: './hamburger.component.html',
  styleUrls: ['./hamburger.component.css']
})
export class HamburgerComponent {
  isNavbarOpen!: boolean ;
  toggleNavbar() {
    this.isNavbarOpen = !this.isNavbarOpen;
  }

  @HostListener('document:click', ['$event'])
  onClick(event: Event) {
    if (this.isNavbarOpen) {
      const target = event.target as HTMLElement;
      if (!target.closest('.navbar') && !target.closest('.hamburger-menu')) {
        this.isNavbarOpen = false;
      }
    }
  }
  

}
