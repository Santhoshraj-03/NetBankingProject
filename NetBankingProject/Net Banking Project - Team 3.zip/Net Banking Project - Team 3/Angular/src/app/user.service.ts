import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  getUserDetails() {
    throw new Error('Method not implemented.');
  }
  
  private apiUrl = 'https://example.com/api/user'; // Replace with your API endpoint

  constructor(private http: HttpClient) { }

  registerUser(userData: User): Observable<any> {
    return this.http.post<any>(this.apiUrl, userData);
  }

  
}
