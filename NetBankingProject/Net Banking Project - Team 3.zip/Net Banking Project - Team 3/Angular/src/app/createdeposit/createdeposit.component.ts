import { Component, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { FixedDeposit } from '../models/fixed-deposit';
import { AccountDetails } from '../models/account-details'; // Assuming you have a model for AccountDetails
import { UserDetails } from '../models/user-details';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-createdeposit',
  templateUrl: './createdeposit.component.html',
  styleUrls: ['./createdeposit.component.css']
})
export class CreatedepositComponent {
  fdForm!: FormGroup;
  isNavbarOpen!: boolean;
  accountDetails: any = {}
  userDetails:any={}


  accountNumber=this.accountService.selectedAccountNumber;
    
  
  
  toggleNavbar() {
    this.isNavbarOpen = !this.isNavbarOpen;
  }

  @HostListener('document:click', ['$event'])
  onClick(event: Event) {
    if (this.isNavbarOpen) {
      const target = event.target as HTMLElement;
      if (!target.closest('.navbar') && !target.closest('.hamburger-menu')) {
        this.isNavbarOpen = false;
      }
    }
  }

  interestRates = [
    { value: 4.5, label: '4.5%' },
    { value: 5, label: '5%' },
    { value: 5.5, label: '5.5%' }
  ];

  constructor(private fb: FormBuilder, private http: HttpClient,private accountService:AccountService) {}

  goToHome() {
    // Navigate to home page
  }

  updateToDate() {
    // Update toDate logic
  }

  ngOnInit(): void {
    this.fdForm = this.fb.group({
      fixedAmount: ['', Validators.required],
      selectedTenure: ['12'],
      interestRate: [{ value: '4.5', disabled: true }],
      fromDate: ['', Validators.required],
      maturityDate: [''],
      maturityAmount: ['']
    });

    this.updateInterestRate();
    this.updateMaturityDate(); 
    this.accountDetails = JSON.parse(localStorage.getItem("currentAccountDetails") || '{}');
    console.log(this.accountDetails);
    this.userDetails = this.accountDetails[0].userDetails;// Assuming userDetails is a property of accountDetails
  }

  updateInterestRate() {
    const selectedTenureControl = this.fdForm.get('selectedTenure');
    const interestRateControl = this.fdForm.get('interestRate');

    if (selectedTenureControl && interestRateControl) {
      const tenure = selectedTenureControl.value;
      let rate = 4.5;

      if (tenure == '24') {
        rate = 5;
      } else if (tenure == '36') {
        rate = 5.5;
      }

      interestRateControl.setValue(rate);
    }
  }

  updateMaturityDate() {
    const selectedTenure = this.fdForm.get('selectedTenure')?.value;
    const fromDateValue = this.fdForm.get('fromDate')?.value;
  
    if (selectedTenure != null && fromDateValue != null) {
      const fromDate = new Date(fromDateValue);
  
      if (!isNaN(fromDate.getTime())) { // Check if fromDate is a valid Date object
        const maturityDate = new Date(fromDate);
        maturityDate.setFullYear(fromDate.getFullYear() + Math.floor(selectedTenure / 12));
  
        this.fdForm.get('maturityDate')?.setValue(maturityDate ? maturityDate.toISOString().split('T')[0] : null);
      } else {
        console.error('Invalid fromDate value');
      }
    } else {
      console.error('Selected tenure or fromDate is null or undefined');
    }
  }
  

  calculate(): void {
    const fixedAmount = this.fdForm.get('fixedAmount')?.value;
    const selectedTenure = this.fdForm.get('selectedTenure')?.value;
    const maturityAmountControl = this.fdForm.get('maturityAmount');

    if (fixedAmount != null && selectedTenure != null) {
      const interestRate = this.fdForm.get('interestRate')?.value;
      const maturityAmount = fixedAmount * (1 + (interestRate / 100) * (selectedTenure / 12));
      maturityAmountControl?.setValue(maturityAmount.toFixed(2));
    }
  }

  // Function to post data to Spring backend
  postDepositData() {
    if (this.fdForm.valid) {
      const depositData: FixedDeposit = new FixedDeposit();
      
      depositData.accNumber=this.accountNumber;
      // Assign values from form to FixedDeposit object
      depositData.fdId = this.fdForm.get('fdId')?.value; // Assuming fdId is a form control in fdForm
      depositData.userDetails = this.userDetails; // Assigning userDetails directly
      depositData.fdAmount = this.fdForm.get('fixedAmount')?.value; // Assuming fixedAmount is a form control in fdForm
      depositData.roi = this.fdForm.get('interestRate')?.value; // Assuming interestRate is a form control in fdForm
      depositData.dateCreate = this.fdForm.get('fromDate')?.value; // Assign the current date
      depositData.matureDate = this.fdForm.get('maturityDate')?.value; // Assuming maturityDate is a form control in fdForm
      depositData.tenure = this.fdForm.get('selectedTenure')?.value; // Assuming selectedTenure is a form control in fdForm
      depositData.matureAmount = this.fdForm.get('maturityAmount')?.value;

      // Assuming your backend endpoint is '/api/deposits'
      this.http.post<any>('http://172.27.17.150:8080/fd/add-fd', depositData).subscribe(
  (response) => {
    // Check if the response contains any error information
    if (response && response.error) {
      console.error('Error posting deposit data:', response.error);
      // Optionally, show an error message to the user
    } else {
      // Handle successful response

      alert("deposit created successfully");
      console.log('Deposit data posted successfully:', response);
      // Optionally, navigate to a success page or show a success message
    }
  },
  (error) => {
    // Handle error
    console.error('Error posting deposit data:', error);
    // Optionally, show an error message to the user
  } 
);

    }
  }
}
