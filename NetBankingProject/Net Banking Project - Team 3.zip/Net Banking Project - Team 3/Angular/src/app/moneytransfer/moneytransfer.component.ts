import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-moneytransfer',
  templateUrl: './moneytransfer.component.html',
  styleUrls: ['./moneytransfer.component.css']
})
export class MoneytransferComponent implements OnInit {
onAccountSelect($event: Event) {
throw new Error('Method not implemented.');
}
  transferForm!: FormGroup;
  accountDetails: any = {};
selectedAccount: any;
accountNumbers: string[] = [];

  constructor(private fb: FormBuilder,private http:HttpClient) {
    this.createTransferForm();
  }
  ngOnInit(): void {
    this.accountDetails = JSON.parse(localStorage.getItem("currentAccountDetails") || '{}');
    // Extract account numbers from accountDetails and populate accountNumbers
    this.accountNumbers = this.accountDetails.map((account: any) => account.accNumber);
  }

  createTransferForm() {
    this.transferForm = this.fb.group({
      amount: ['', Validators.required],
      issuer_account: ['', Validators.required],
      receiver_account: ['', Validators.required],
      account_holder_name: ['', Validators.required],
      ifsc_code: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.transferForm.valid) {
      const currentDate = new Date();
      const transactionDetails = {
        transAmount: this.transferForm.value.amount,
        transType: 'debit',
        accNo:this.transferForm.value.issuer_account,
      
        receiverAccNo: this.transferForm.value.receiver_account,
        status: 'sucessful',
        transDate: currentDate
      };
      // Send transactionDetails to backend
      console.log('Transaction details:', transactionDetails);
      this.http.post<any>('http://172.27.17.150:8080/transaction/add-transaction', transactionDetails)
      .subscribe(
        (response) => {
          alert("Transfered successfully");
          console.log('Transaction details sent successfully:', response);
          // Handle success response from the backend
        },
        (error) => {
          console.error('Error sending transaction details:', error);
          alert("Transfered successfully");
          // Handle error response from the backend
        }
      );
    } else {
      // Handle form validation errors
    }
  }

}
