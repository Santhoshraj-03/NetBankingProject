import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-updatedetails',
  templateUrl: './updatedetails.component.html',
  styleUrls: ['./updatedetails.component.css']
})
export class Updatedetailscomponent implements OnInit {
  updateForm!: FormGroup;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.updateForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      contact: ['', Validators.pattern('[0-9]+')],
      address: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.updateForm.valid) {
      // Perform update operation here
      console.log(this.updateForm.value);
    }
  }
}