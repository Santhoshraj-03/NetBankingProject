import { AccountDetails } from './account-details'; // Assuming you have an AccountDetails class defined

export class ChequeDetails {
  chequeNo: number;
  issuerAccNo: AccountDetails;
  receiverAccNo: AccountDetails;
  chequeAmount: number;
  chequeDate: Date;

  status: string;

  constructor(
    chequeNo: number,
    issuerAccNo: AccountDetails,
    receiverAccNo: AccountDetails,
    chequeAmount: number,
    chequeDate: Date,
   
    status: string
  ) {
    this.chequeNo = chequeNo;
    this.issuerAccNo = issuerAccNo;
    this.receiverAccNo = receiverAccNo;
    this.chequeAmount = chequeAmount;
    this.chequeDate = chequeDate;
  
    this.status = status;
  }
}
