import { FixedDeposit } from './fixed-deposit';

describe('FixedDeposit', () => {
  it('should create an instance', () => {
    expect(new FixedDeposit()).toBeTruthy();
  });
});
