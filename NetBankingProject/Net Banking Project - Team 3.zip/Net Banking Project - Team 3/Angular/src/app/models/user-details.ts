export class UserDetails {
    userId: number;
    firstName: string;
    lastName: string;
    emailId: string;
    address: string;
    mobile: number;
    dob?: Date|null;
    gender: string;
    userName: string;
    password: string;
    loginCount: number;
    accStatus: string;
  
    constructor(
      userId: number,
      firstName: string,
      lastName: string,
      emailId: string,
      address: string,
      mobile: number,
      dob: Date,
      gender: string,
      userName: string,
      password: string,
      loginCount: number,
      accStatus: string
    ) {
      this.userId = userId;
      this.firstName = firstName;
      this.lastName = lastName;
      this.emailId = emailId;
      this.address = address;
      this.mobile = mobile;
      this.dob = dob;
      this.gender = gender;
      this.userName = userName;
      this.password = password;
      this.loginCount = loginCount;
      this.accStatus = accStatus;
    }
  }
  