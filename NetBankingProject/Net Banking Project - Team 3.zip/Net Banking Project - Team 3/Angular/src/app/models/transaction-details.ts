import { AccountDetails } from "./account-details"



export class TransactionDetails {
    transId: number;
    accNo: AccountDetails;
    transAmount: number;
    transType: string;
    receiverAccNo: AccountDetails;
    status: string;
    transDate: Date;    

    constructor(
        transId: number,
        accNo: AccountDetails,
        transAmount: number,
        transType: string,
        receiverAccNo: AccountDetails,
        status: string,
        transDate: Date
    ) {
        this.transId = transId;
        this.accNo = accNo;
        this.transAmount = transAmount;
        this.transType = transType;
        this.receiverAccNo = receiverAccNo;
        this.status = status;
        this.transDate = transDate;
    }
}
