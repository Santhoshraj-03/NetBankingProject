import { UserDetails } from "./user-details";

export class FixedDeposit {
    accNumber!:number;
    fdId!: number;
    userDetails!: UserDetails;
    fdAmount!: number;
    roi!: number;
    dateCreate!: Date;
    matureDate!: Date;
    tenure!: number;
    matureAmount!: number;
}