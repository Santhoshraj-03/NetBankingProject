import { ChequeDetails } from './cheque-details';

describe('ChequeDetails', () => {
  it('should create an instance', () => {
    expect(new ChequeDetails()).toBeTruthy();
  });
});
