import { UserDetails } from './user-details'; // Assuming you have a UserDetails class defined

export class AccountDetails {
  accNumber!: number;
  userDetails!: UserDetails;
  balance!: number;
  odOpted!: string;
  odBalance!: number;
  odCharges!: number;
  accType!: string;
  
  // constructor(
  //   accNumber: number,
  //   userDetails: UserDetails,
  //   balance: number,
  //   odOpted: string,
  //   odBalance: number,
  //   odCharges: number,
  //   accType: string
  // ) {
  //   this.accNumber = accNumber;
  //   this.userDetails = userDetails;
  //   this.balance = balance;
  //   this.odOpted = odOpted;
  //   this.odBalance = odBalance;
  //   this.odCharges = odCharges;
  //   this.accType = accType;
  // }
}
