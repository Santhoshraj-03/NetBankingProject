import { Component, HostListener, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-fixed-deposit',
  templateUrl: './fixeddeposit.component.html',
  styleUrls: ['./fixeddeposit.component.css']
})
export class FixedDepositComponent implements OnInit {
  fdForm!: FormGroup; 
  isNavbarOpen!: boolean;
  toggleNavbar() {
    this.isNavbarOpen = !this.isNavbarOpen;
  }

  @HostListener('document:click', ['$event'])
  onClick(event: Event) {
    if (this.isNavbarOpen) {
      const target = event.target as HTMLElement;
      if (!target.closest('.navbar') && !target.closest('.hamburger-menu')) {
        this.isNavbarOpen = false;
      }
    }
  }
  interestRates = [
    { value: 4.5, label: '4.5%' },
    { value: 5, label: '5%' },
    { value: 5.5, label: '5.5%' }
  ];

  constructor(private fb: FormBuilder) {}


goToHome() {
// throw new Error('Method not implemented.');
}
updateToDate() {
// throw new Error('Method not implemented.');
}


 

  ngOnInit(): void {
    
    this.fdForm = this.fb.group({
      fixedAmount: ['', Validators.required],
      selectedTenure: ['12'],
      interestRate: [{ value: '4.5', disabled: true }], 
      fromDate: ['', Validators.required],
      maturityDate: [''],
      maturityAmount: ['']
    });

    this.updateInterestRate(); 
    this.updateMaturityDate();
  }

  updateInterestRate() {
    const selectedTenureControl = this.fdForm.get('selectedTenure');
    const interestRateControl = this.fdForm.get('interestRate');

    if (selectedTenureControl && interestRateControl) { 
      const tenure = selectedTenureControl.value;
      let rate = 4.5;

      if (tenure == '24') {
        rate = 5;
      } else if (tenure == '36') {
        rate = 5.5;
      }

      interestRateControl.setValue(rate);
    }
  }

  updateMaturityDate() {
    const selectedTenure = this.fdForm.get('selectedTenure')?.value;
    const fromDate = new Date(this.fdForm.get('fromDate')?.value);
  
    if (selectedTenure != null && fromDate != null) {
      const maturityDate = new Date(fromDate);
  
      // Adjust maturity date based on selected tenure
      maturityDate.setFullYear(fromDate.getFullYear() + Math.floor(selectedTenure / 12));
  
      this.fdForm.get('maturityDate')?.setValue(maturityDate.toISOString().split('T')[0]);
    }
  }
   

  calculate():void {
    const fixedAmount = this.fdForm.get('fixedAmount')?.value;
    const selectedTenure = this.fdForm.get('selectedTenure')?.value;
    const interestRate = this.fdForm.get('interestRate')?.value;
    const maturityAmountControl = this.fdForm.get('maturityAmount');

    if (fixedAmount != null && selectedTenure != null && interestRate != null) {
        if (fixedAmount != null && selectedTenure != null && interestRate != null) {
        const maturityAmount = fixedAmount * (1 + (interestRate / 100) * (selectedTenure / 12));
        maturityAmountControl?.setValue(maturityAmount.toFixed(2));  }
}}
}