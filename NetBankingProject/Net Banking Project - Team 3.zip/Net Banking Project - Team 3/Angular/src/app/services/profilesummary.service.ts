import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileSummaryService {

  constructor(private http: HttpClient) { }

  getUserInfo(): Observable<any> {
    return this.http.get('/user-info-endpoint'); 
  }

  updateUserInfo(updatedInfo: any): Observable<any> {
    return this.http.post('/update-user-info-endpoint', updatedInfo); 
  }
}
