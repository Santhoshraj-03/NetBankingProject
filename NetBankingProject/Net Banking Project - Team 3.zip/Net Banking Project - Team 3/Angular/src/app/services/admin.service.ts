import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, tap } from 'rxjs';
import { ChequeDetails } from '../models/cheque-details';
import { UserDetails } from '../models/user-details';


@Injectable({
  providedIn: 'root'
})

export class AdminService {

  private getUserAdmitApiUrl = "http://172.27.17.150:8080/admin/get-pending-users";
  private getChequeReqApiUrl = "http://172.27.17.150:8080/admin/get-claimed-cheques";
  private getSeizedAccountsApiUrl = "http://172.27.17.150:8080/admin/get-blocked-users";
  private acceptActivateReqUrl = "http://172.27.17.150:8080/admin/unblock-user";
  private updateUserStatus = "http://172.27.17.150:8080/admin/verify-user";
  private verifyChequeRequestApiUrl = "http://172.27.17.150:8080/admin/verify-cheque"
  private approveCheque = "http://172.27.17.150:8080/admin/approve-cheque"
  // private user: any[] =[];

  a: boolean = false;
  constructor(private httpClient: HttpClient) { }

  getRequests() {
    return this.httpClient.get(this.getUserAdmitApiUrl).pipe(
      map((res: any) => { return res })
    )
  }


  geChequeRequests() {
    return this.httpClient.get(this.getChequeReqApiUrl).pipe(
      map((res: any) => { return res })
    )
  }

  getSeizedAccounts() {
    return this.httpClient.get(this.getSeizedAccountsApiUrl).pipe(
      map((res: any) => { return res })
    )
  }

  reactivateUser(id: number): Observable<any> {
    const url = `${this.acceptActivateReqUrl}/${id}`
    return this.httpClient.put<any>(url, { observe: "response" }).pipe(
      tap(response => response),
      catchError(error => {
        throw error;
      })
    );
  }

  updateChequeStatus(cheque: ChequeDetails): Observable<any> {
    const url = `${this.approveCheque
      }`
    return this.httpClient.put<any>(url, cheque, { observe: "response" }).pipe(
      tap(response => response),
      catchError(error => {
        throw error;
      })
    );
  }


  verifyChequeRequest(cheque: any): Observable<any> {
    const url = `${this.verifyChequeRequestApiUrl}`;
    return this.httpClient.put(url, cheque);
  }
}