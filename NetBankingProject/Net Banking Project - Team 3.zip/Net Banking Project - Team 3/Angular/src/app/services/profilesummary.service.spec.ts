import { TestBed } from '@angular/core/testing';

import { ProfileSummaryService } from './profilesummary.service';

describe('ProfilesummaryService', () => {
  let service: ProfileSummaryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProfileSummaryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
