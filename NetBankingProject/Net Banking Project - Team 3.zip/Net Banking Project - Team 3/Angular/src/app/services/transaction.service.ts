import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TransactionDetails } from '../models/transaction-details';


@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private apiUrl = 'http://your-backend-url/api/transactions'; // Replace this with your actual API URL

  constructor(private http: HttpClient) { }

  getTransactionsByAccountNo(accountNo: string): Observable<TransactionDetails[]> {
    const url = `${this.apiUrl}?accountNo=${accountNo}`;
    return this.http.get<TransactionDetails[]>(url);
  }
}
