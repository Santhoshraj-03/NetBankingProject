import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {
  createAccountForm!: FormGroup;
  accountDetails: any = {};
  userDetails: any = {};

  constructor(private fb: FormBuilder, private http: HttpClient) { }

  ngOnInit(): void {
    this.createAccountForm = this.fb.group({
      accType: ['', Validators.required], // Assuming accountType is required
      odOpted: ['no']
    });

    // Fetch account details from local storage
    this.accountDetails = JSON.parse(localStorage.getItem("currentAccountDetails") || '{}');
    console.log(this.accountDetails);

    // Assuming userDetails is present in the first item of accountDetails array
    if (this.accountDetails.length > 0) {
      this.userDetails = this.accountDetails[0].userDetails;
    }
  }

  onSubmit(): void {
    if (this.createAccountForm.valid) {
      const formData = {
        ...this.createAccountForm.value,
        userDetails: this.userDetails // Include userDetails in the form data
      };

      // Assuming your backend endpoint is '/api/createAccount'
      this.http.post('http://172.27.17.150:8080/account/add-account', formData)
      .subscribe(
        (response: any) => {
          // Check if the response contains an error field
          if (response && response.error) {
            console.error('Error posting deposit data:', response.error);
            // Optionally, show an error message to the user
          } else {
            // Handle successful response
            console.log(' Account created successfully:', response);
            // Show success message to the user
            alert("Account created successfully");
            // Optionally, navigate to a success page or show a success message
          }
        },
        (error: HttpErrorResponse) => {
          if (error.status === 200) {
            // Treat status 200 as a success, handle it accordingly
            console.log('Success, but unexpected response:', error);
            alert("Account created successfully");
          } else {
            // Handle other error cases
            console.error('Error posting data', error);
            // Optionally, show an error message to the user
          }
        }
      );
    
    } else {
      // Form is invalid, handle validation errors if needed
    }
  }
}
