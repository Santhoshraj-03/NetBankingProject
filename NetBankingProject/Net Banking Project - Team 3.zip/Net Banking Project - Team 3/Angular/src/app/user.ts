export class User {
    firstName: string;
    lastName: string;
    dob: Date;
    gender: string;
    phone: string;
    address: string;
    email: string;
    username: string;
    password: string;
    accountType: string;
    overdraft: string;
  
    constructor(
      firstName: string = '',
      lastName: string = '',
      dob: Date = new Date(),
      gender: string = '',
      phone: string = '',
      address: string = '',
      email: string = '',
      username: string = '',
      password: string = '',
      accountType: string = 'savings',
      overdraft: string = 'no'
    ) {
      this.firstName = firstName;
      this.lastName = lastName;
      this.dob = dob;
      this.gender = gender;
      this.phone = phone;
      this.address = address;
      this.email = email;
      this.username = username;
      this.password = password;
      this.accountType = accountType;
      this.overdraft = overdraft;
    }
  }
  