import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserhomepageComponent } from './userhomepage/userhomepage.component';
import { FixedDepositComponent } from './fixeddeposit/fixeddeposit.component';
import { ChequeDepositComponent } from './chequedeposit/chequedeposit.component';
import { MoneytransferComponent } from './moneytransfer/moneytransfer.component';
import { ProfilesummaryComponent } from './profilesummary/profilesummary.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { TransactionDetailsComponent } from './transactiondetails/transactiondetails.component';
import { MiniStatementComponent } from './ministatement/ministatement.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { HttpClientModule } from '@angular/common/http';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { Updatedetailscomponent } from './updatedetails/updatedetails.component';
import { ReactivateAccountComponent } from './adminpage/reactivate-account/reactivate-account.component';
import { ChequeValidationComponent } from './adminpage/cheque-validation/cheque-validation.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { UserRequestComponent } from './adminpage/user-request/user-request.component';
import { HamburgerComponent } from './hamburger/hamburger.component';
import { CreatedepositComponent } from './createdeposit/createdeposit.component';
import { ShowdepositsComponent } from './showdeposits/showdeposits.component';
import { ShowchequedepositComponent } from './showchequedeposit/showchequedeposit.component';
import { ChequeComponent } from './cheque/cheque.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    AdminloginComponent,
    HomepageComponent,
    UserhomepageComponent,
    FixedDepositComponent,
    ChequeDepositComponent,
    MoneytransferComponent,
    ProfilesummaryComponent,
    UserloginComponent,
    TransactionDetailsComponent,
    MiniStatementComponent,
    CreateaccountComponent,
    ForgotpasswordComponent,
    Updatedetailscomponent,
    ReactivateAccountComponent,
    ChequeValidationComponent,
    AdminpageComponent,
    UserRequestComponent,
    HamburgerComponent,
    CreatedepositComponent,
    ShowdepositsComponent,
    ShowchequedepositComponent,
    ChequeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule, 
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
