import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, HostListener, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-userhomepage',
  templateUrl: './userhomepage.component.html',
  styleUrls: ['./userhomepage.component.css']
})
export class UserhomepageComponent implements OnInit {
  accountDetails: any = {};
  accountDetails1: any = {};


  isNavbarOpen: boolean = false;
  transactions: any[] = [];
  statementForm!: FormGroup;
  selectedAccountNumber: number = 0;
  accountNumbers: string[] = [];
  
  @Output() accountSelected = new EventEmitter<number>();

  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient,
    private accountService: AccountService
  ) {}

  toggleNavbar() {
    this.isNavbarOpen = !this.isNavbarOpen;
  }

  @HostListener('document:click', ['$event'])
  onClick(event: Event) {
    if (this.isNavbarOpen) {
      const target = event.target as HTMLElement;
      if (!target.closest('.navbar') && !target.closest('.hamburger-menu')) {
        this.isNavbarOpen = false;
      }
    }
  }

  onAccountSelect(event: any) {
    this.accountService.selectedAccountNumber = +event.target.value;

    this.fetchAccountDetailsAndTransactions(this.accountService.selectedAccountNumber);
    console.log(this.accountService.selectedAccountNumber);
    
  }

  ngOnInit(): void {
    // Fetch account details from local storage
    this.accountDetails = JSON.parse(localStorage.getItem("currentAccountDetails") || '{}');
    // Extract account numbers from accountDetails and populate accountNumbers
    this.accountNumbers = this.accountDetails.map((account: any) => account.accNumber);

    // Set a default selected account number if available
    if (this.accountNumbers.length > 0) {
      this.accountService.selectedAccountNumber = +this.accountNumbers[0];
      this.fetchAccountDetailsAndTransactions(this.accountService.selectedAccountNumber);
    }

    // Initialize the statement form
    this.statementForm = this.formBuilder.group({
      date: [''],
      type: [''],
      amount: [''],
      balance: ['']
    });
  }

  fetchAccountDetailsAndTransactions(accountNumber: number) {
    // Fetch account details
    this.http.get<any>(`http://172.27.17.150:8080/account/get-account-by-accnumber/${accountNumber}`)
      .subscribe(
        (response) => {
          this.accountDetails1 = response;
          console.log(response);
          
        },
        (error) => {
          console.error('Error fetching account details:', error);
          // Handle error (e.g., display an error message)
        }
      );
  
    // Fetch transaction details based on the selected account number
    this.http.get<any[]>(`http://172.27.17.150:8080/transaction/last-5-transactions/${accountNumber}`)
      .subscribe(
        (response) => {
          this.transactions = response;
          console.log(response);
        },
        (error) => {
          console.error('Error fetching transactions:', error);
          // Handle error (e.g., display an error message)
        }
      );
  }
  
}
