import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowdepositsComponent } from './showdeposits.component';

describe('ShowdepositsComponent', () => {
  let component: ShowdepositsComponent;
  let fixture: ComponentFixture<ShowdepositsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowdepositsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowdepositsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
