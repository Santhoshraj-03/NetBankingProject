import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, HostListener } from '@angular/core';
import { FixedDeposit } from '../models/fixed-deposit';

@Component({
  selector: 'app-showdeposits',
  templateUrl: './showdeposits.component.html',
  styleUrls: ['./showdeposits.component.css']
})
export class ShowdepositsComponent {
  isNavbarOpen: boolean = false;
  fixedDeposits: FixedDeposit[] = [];
  errorMessage: string = '';

  constructor(private http: HttpClient) { }

  toggleNavbar() {
    this.isNavbarOpen = !this.isNavbarOpen;
  }

  @HostListener('document:click', ['$event'])
  onClick(event: Event) {
    if (this.isNavbarOpen) {
      const target = event.target as HTMLElement;
      if (!target.closest('.navbar') && !target.closest('.hamburger-menu')) {
        this.isNavbarOpen = false;
      }
    }
  }

  ngOnInit(): void {
    this.fetchFixedDeposits();
  }

  fetchFixedDeposits() {
    this.http.get<FixedDeposit[]>('http://172.27.17.150:8080/fd/get-all-fd')
      .subscribe(
        (data: FixedDeposit[]) => {
          this.fixedDeposits = data;
        },
        (error: HttpErrorResponse) => {
          this.errorMessage = error.message || 'Failed to fetch fixed deposits.';
        }
      );
  }
}
