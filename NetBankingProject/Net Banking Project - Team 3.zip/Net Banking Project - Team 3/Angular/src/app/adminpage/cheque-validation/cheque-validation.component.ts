import { Component, OnInit } from '@angular/core';
import { ChequeDetails } from 'src/app/models/cheque-details';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-cheque-validation',
  templateUrl: './cheque-validation.component.html',
  styleUrls: ['./cheque-validation.component.css']
})
export class ChequeValidationComponent implements OnInit {
  reqList: ChequeDetails[] = [];
  msg: string = '';

  constructor(private adminService: AdminService) { }

  ngOnInit(): void {
    this.getAllRequests();
  }

  getAllRequests(): void {
    this.adminService.geChequeRequests().subscribe(
      (res: ChequeDetails[]) => {
        this.reqList = res;
      },
      (error: any) => {
        console.error('Error fetching cheque requests:', error);
      }
    );
  }

 updateAcceptStatus(cheque: ChequeDetails): void {
  this.adminService.verifyChequeRequest(cheque).subscribe(
    (response: boolean) => {
      cheque.status = response ? 'cleared' : 'bounced';
      cheque.chequeDate = new Date();
      this.adminService.updateChequeStatus(cheque).subscribe(
        (response: any) => {
          // Update the clearanceDate to current date
          alert("approved succesfully");
          this.reqList = this.reqList.filter(item => item !== cheque);

          console.log(response);
        },
        (error: any) => {
          alert("approved succesfully");
          console.log(error);
        }
      );
    },
    (error: any) => {
      alert("approved succesfully");
      console.error('Error submitting cheque request:', error);
    }
  );
}
updateDenyStatus(cheque: ChequeDetails): void {
  this.adminService.verifyChequeRequest(cheque).subscribe(
    (response: boolean) => {
      cheque.status = response ? 'bounced' : 'cleared';
      cheque.chequeDate = new Date();
      this.adminService.updateChequeStatus(cheque).subscribe(
        (response: any) => {
          // Update the clearanceDate to current date
          alert("denied succesfully");
          this.reqList = this.reqList.filter(item => item !== cheque);

          console.log(response);
        },
        (error: any) => {
          alert("denied succesfully");
          console.log(error);
        }
      );
    },
    (error: any) => {
      alert("denied succesfully");
      console.error('Error submitting cheque request:', error);
    }
  );
}

}
