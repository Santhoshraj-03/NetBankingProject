import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { UserDetails } from 'src/app/models/user-details';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-reactivate-account',
  templateUrl: './reactivate-account.component.html',
  styleUrls: ['./reactivate-account.component.css']
})
export class ReactivateAccountComponent implements OnInit {
  requests: any[] = [];
  msg!: string;
  reqList: any[] = [];

  constructor(private adminService: AdminService) { }

  ngOnInit(): void {
    this.getAllRequests();
  }

  getAllRequests() {
    this.adminService.getSeizedAccounts().subscribe(res => (
      this.reqList = res
    ));
    console.log(this.reqList);
  }
  denyRequest(index: number) {
    // Clear the reqList array
    this.reqList = [];
  }

  activateUser(id: number) {
    this.adminService.reactivateUser(id).subscribe(
      (response: HttpResponse<any>) => {
        alert("Reactivated user " + id + " successfully!!");
        this.reqList = this.reqList.filter(item => item !== UserDetails);
      },
      (error: HttpErrorResponse) => {
        this.msg = error.error.title;
      }
    );
    this.getAllRequests();
  }
}
