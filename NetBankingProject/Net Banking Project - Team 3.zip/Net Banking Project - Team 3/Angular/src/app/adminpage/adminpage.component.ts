import { Component } from '@angular/core';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent {
  constructor() {}

  // Initializing the showTable object to manage the visibility of different tables
  showTable: any = {
    accountCreation: false,
    chequeValidation: false,
    acceptedRequests: false,
    deniedRequests: false,
    accepted1Requests: false,
    denied1Requests: false
  };
  
  // Method to toggle the visibility of tables based on the button clicked
  toggleTable(table: string) {
    this.showTable[table] = !this.showTable[table];
  }

  // Sample data for account creation requests
  accountCreationData: any[] = [
    {
      userName: 'sujith',
      email: 'sujith@gmail.com',
      phoneNumber: '9356290099',
      accountNumber: '643631',
      accountType: 'Savings',
      status: 'Pending'
    }
  ];

  // Arrays to store accepted and denied account creation requests
  acceptedRequests: any[] = [];
  deniedRequests: any[] = [];
 
  // Method to accept an account creation request
  acceptRequest(index: number) {
    const request = this.accountCreationData.splice(index, 1)[0];
    request.status = 'Accepted';
    this.acceptedRequests.push(request);
  }

  // Method to deny an account creation request
  denyRequest(index: number) {
    const request = this.accountCreationData.splice(index, 1)[0];
    request.status = 'Denied';
    this.deniedRequests.push(request);
  }

  // Sample data for cheque validation requests
  chequeValidation: any[] = [
    {
      IssuerAccNo: '15643',
      BeniAccNo: '96874',
      ChequeNo: '7598012',
      DepositeDate: '16.08.2003',
      ChequeAmount: '290232',
      status: 'Pending'
    }
  ];

  // Arrays to store accepted and denied cheque validation requests
  accepted1Requests: any[] = [];
  denied1Requests: any[] = [];
 
  // Method to accept a cheque validation request
  accept1Request(index: number) {
    const request = this.chequeValidation.splice(index, 1)[0];
    request.status = 'Accepted1';
    this.accepted1Requests.push(request);
  }

  // Method to deny a cheque validation request
  deny1Request (index: number) {
    const request = this.chequeValidation.splice(index, 1)[0];
    request.status = 'Denied2'; // Fixed status name to 'Denied1'
    this.denied1Requests.push(request);
  }
}
