import { Component } from '@angular/core';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import {  OnInit } from '@angular/core';
import { UserDetails} from 'src/app/models/user-details';
import { AdminService } from 'src/app/services/admin.service';


@Component({
  selector: 'app-user-request',
  templateUrl: './user-request.component.html',
  styleUrls: ['./user-request.component.css']
})
export class UserRequestComponent implements OnInit {
  requests: any[] =[];
  msg !: string;
  reqList: any[] = [];

  constructor(private adminService: AdminService) { }

  ngOnInit(): void {
    console.log("onitis called");
    
    this.getAllRequests()
  }

  getAllRequests(){
    console.log("get all req s called");
    
    this.adminService.getRequests().subscribe(res => (
      this.reqList=res
    ));
    console.log(this.reqList);
    
  }

  activateUser(id: number){
    this.adminService.reactivateUser(id).subscribe(
      (response: HttpResponse<any>) => {
        alert("Activated user "+ id +" successfully!!");
        // console.log(this.msg);
      },
      (error: HttpErrorResponse) => {
        this.msg = error.error.title;
        // console.log(this.msg);
      }
    );
    this.getAllRequests()
  }
  denyRequest(index: number) {
    // Clear the reqList array
    this.reqList = [];
  }

}
