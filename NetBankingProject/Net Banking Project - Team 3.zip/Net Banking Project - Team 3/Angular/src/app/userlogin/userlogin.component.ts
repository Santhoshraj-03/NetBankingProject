import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserDetails } from '../models/user-details';
import { AccountDetails } from '../models/account-details';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  accountDetails!: AccountDetails;

  userId!:number;

  loginForm!: FormGroup;
  remainingAttempts: number = 3;
  warningMessage: string = ''; // Added property for warning message

  constructor(private formBuilder: FormBuilder, private http: HttpClient,private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onLogin() {
    if (this.loginForm.invalid) {
      return;
    }

    const userDetails: UserDetails = {
      userId:0,
      userName: this.loginForm.value.username,
      password: this.loginForm.value.password,
      firstName: 'John', // Example: fill with actual data
      lastName: 'Doe', // Example: fill with actual data
      emailId: 'john@example.com', // Example: fill with actual data
      address: '123 Main Street', // Example: fill with actual data
      mobile: 1234567890, // Example: fill with actual data
      dob: new Date('1990-01-01'), // Example: fill with actual data
      gender: 'Male', // Example: fill with actual data
      loginCount: 0, // Default value
      accStatus: 'Active' // Default value
    };

    this.http.post<any>('http://172.27.17.150:8080/user/verify-login', userDetails)
    .subscribe(
      (response:any) => {
        // Login successful, handle response
        alert('Login successful!');
        console.log('Login successful:', response);
        localStorage.setItem("currentAccountDetails",JSON.stringify(response));
        // Assuming account details are returned in the response
        this.router.navigate(['/userhome']);
// Adjust accordingly to your API response
        // console.log('State to be passed:', { accountDetails: response });

      },
      (error) => {
        // Login failed, handle error
        alert ("invalid credentials")
        // Handle error as per your requirement
      }
    );
}
}

