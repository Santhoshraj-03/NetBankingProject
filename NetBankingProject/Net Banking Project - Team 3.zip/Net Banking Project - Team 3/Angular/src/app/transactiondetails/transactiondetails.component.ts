import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AccountService } from '../account.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-transaction-details',
  templateUrl: './transactiondetails.component.html',
  styleUrls: ['./transactiondetails.component.css']
})
export class TransactionDetailsComponent implements OnInit {
  transactionForm!: FormGroup;
  accountNumber: number;
  transactions: TransactionDetails[] = []; // Array to hold transaction details

  constructor(private formBuilder: FormBuilder, private accountService: AccountService, private http: HttpClient) {
    this.accountNumber = this.accountService.selectedAccountNumber;
  }

  ngOnInit(): void {
    this.transactionForm = this.formBuilder.group({
      fromDate: [''],
      toDate: ['']
    });
    console.log(this.accountNumber);
    
  }

  onSubmit() {
    // Fetch transactions based on form values
    const formData = this.transactionForm.value;
    const { fromDate, toDate } = formData;

// Convert fromDate and toDate to the required format ("dd-mmm-yyyy")
const formatDate = (date: Date): string => {
  const day = date.getDate().toString().padStart(2, '0'); // Ensure two digits for day
  const month = new Intl.DateTimeFormat('en-US', { month: 'short' }).format(date).toLowerCase(); // Get abbreviated month
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

// Example usage
const fromDateFormatted = formatDate(new Date(fromDate));
const toDateFormatted = formatDate(new Date(toDate));

// Construct the URL with formatted dates
const url = `http://172.27.17.150:8080/transaction/get-transactions-by-date?accNo=${this.accountNumber}&fromDate=${fromDateFormatted}&toDate=${toDateFormatted}`;



    console.log(url);
    
    // Make an HTTP POST request to your backend API
    this.http.get<any>(url, { }).subscribe(
      
      response => {
   console.log(response);
        // Update transactions array with the response
        this.transactions = response;
        console.log('Transaction details fetched:', this.transactions);
      },
      error => {
       console.log("inside the api");
        console.error('Error occurred while fetching transaction details:', error);
      }
    );
  }
}

// Define a model for TransactionDetails
export class TransactionDetails {
  transId!: number;
  accNo!: AccountDetails;
  transAmount!: number;
  transType!: string;
  receiverAccNo!: AccountDetails;
  status!: string;
  transDate!: Date;
}

// Define a model for AccountDetails
export class AccountDetails {
  accNumber!: number;
}
