import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent {
  loginForm!: FormGroup;

  constructor(private formBuilder: FormBuilder,private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  login() {
    if (this.loginForm.valid) {
      // Implement your authentication logic here
      const username = this.loginForm.value.username;
      const password = this.loginForm.value.password;
      if (username === 'admin' && password === 'password') {
        alert('Login successful!');
        this.router.navigate(['/adminpage']);
        
      } else {
        alert('Invalid username or password. Please try again.');
      }
    }
  }
}
